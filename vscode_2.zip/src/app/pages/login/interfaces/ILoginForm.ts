import { FormControl } from '@angular/forms';

export interface ILoginForm {
  usuario: FormControl<string | null>;
  contraseña: FormControl<string | null>;
}
