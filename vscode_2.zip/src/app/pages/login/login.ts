import { Component } from '@angular/core';
import { PrimeImportsModule } from '../../primeng-imports';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ILoginForm } from './interfaces/ILoginForm';
import { MessageService } from 'primeng/api';
import { Toast } from 'primeng/toast';
import { Ripple } from 'primeng/ripple';
import { AuthService } from '../../core/services/auth-service';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [PrimeImportsModule, Toast, Ripple],
  templateUrl: './login.html',
  styleUrl: './login.css',
  providers: [MessageService],
})
export class Login {
  constructor(
    private fb: FormBuilder,
    private messageService: MessageService,
    private auth: AuthService
  ) {}

  formLogin!: FormGroup<ILoginForm>;

  ngOnInit(): void {
    this.formLogin = this.fb.group({
      usuario: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      contraseña: ['', [Validators.required]],
    });
  }

  submit() {
    if (this.formLogin.invalid) {
      this.formLogin.markAllAsTouched();
      this.showError();
      return;
    }
    alert('todo ok');
  }

  showError() {
    this.messageService.add({
      severity: 'error',
      summary: 'Error',
      detail: 'No iniciar sesión, intente nuevamente.',
    });
  }
}
