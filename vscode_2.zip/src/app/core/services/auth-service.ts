import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IResponseData } from '../interfaces/IResponseData';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private _httpclient: HttpClient) {}

  private url = 'http://localhost:8000/ApiGateway/Login/InicioSesion';

  login(credentials: { usuario: string; contraseña: string }): Observable<IResponseData> {
    return this._httpclient.post<IResponseData>(this.url, credentials);
  }
}
