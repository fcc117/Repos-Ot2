//import { IUserData } from './IUserData';
//import { IMenuItem } from './IMenuItem';

export interface IResponseData {
  data: any;
  objectlist: any;
  objects: null;
  value: number;
  rows: number;
  token: string;
  expire: number;
  exito: boolean;
  error: string;
  codeError: string;
  httpStatusCode: number;
  sValor: null;
}
