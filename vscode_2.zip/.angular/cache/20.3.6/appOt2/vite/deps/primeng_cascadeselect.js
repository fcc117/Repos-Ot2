import {
  Overlay
} from "./chunk-SQKMNAVN.js";
import {
  Fluid
} from "./chunk-KHY53XKV.js";
import {
  BaseEditableHolder
} from "./chunk-4UTIREIR.js";
import "./chunk-HWODBN6L.js";
import {
  AutoFocus
} from "./chunk-3T5NMV4M.js";
import "./chunk-UJ6Z4JT4.js";
import {
  NG_VALUE_ACCESSOR
} from "./chunk-OWDQLOGR.js";
import {
  Ripple
} from "./chunk-SQGMOSB7.js";
import {
  AngleRightIcon,
  ChevronDownIcon,
  TimesIcon
} from "./chunk-C2ZHMGR2.js";
import "./chunk-ZKMQJGIN.js";
import "./chunk-DGG7IRJQ.js";
import "./chunk-63OXDA6E.js";
import "./chunk-KGGKRTM5.js";
import {
  BaseComponent
} from "./chunk-HWI5RFTJ.js";
import {
  BaseStyle
} from "./chunk-HOGF5KIF.js";
import "./chunk-FVVHOTUL.js";
import {
  OverlayService,
  PrimeTemplate,
  SharedModule,
  TranslationKeys
} from "./chunk-ATRP6CAE.js";
import {
  J,
  K,
  M,
  P,
  a,
  bt,
  c,
  h,
  j2 as j,
  k2 as k,
  s2 as s,
  s3 as s2,
  v,
  z
} from "./chunk-QUD74IZO.js";
import {
  CommonModule,
  NgForOf,
  NgIf,
  NgStyle,
  NgTemplateOutlet
} from "./chunk-3VWL36ZD.js";
import "./chunk-ZMLREZMJ.js";
import {
  ChangeDetectionStrategy,
  Component,
  ContentChild,
  ContentChildren,
  EventEmitter,
  HostListener,
  Injectable,
  Input,
  NgModule,
  Output,
  ViewChild,
  ViewEncapsulation,
  booleanAttribute,
  computed,
  effect,
  forwardRef,
  inject,
  input,
  numberAttribute,
  setClassMetadata,
  signal,
  ɵɵInheritDefinitionFeature,
  ɵɵNgOnChangesFeature,
  ɵɵProvidersFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction1,
  ɵɵpureFunction2,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleMap,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty,
  ɵɵviewQuery
} from "./chunk-QLQLW64P.js";
import {
  __spreadProps,
  __spreadValues
} from "./chunk-KWSTWQNB.js";

// node_modules/@primeuix/styles/dist/cascadeselect/index.mjs
var style = "\n    .p-cascadeselect {\n        display: inline-flex;\n        cursor: pointer;\n        position: relative;\n        user-select: none;\n        background: dt('cascadeselect.background');\n        border: 1px solid dt('cascadeselect.border.color');\n        transition:\n            background dt('cascadeselect.transition.duration'),\n            color dt('cascadeselect.transition.duration'),\n            border-color dt('cascadeselect.transition.duration'),\n            outline-color dt('cascadeselect.transition.duration'),\n            box-shadow dt('cascadeselect.transition.duration');\n        border-radius: dt('cascadeselect.border.radius');\n        outline-color: transparent;\n        box-shadow: dt('cascadeselect.shadow');\n    }\n\n    .p-cascadeselect:not(.p-disabled):hover {\n        border-color: dt('cascadeselect.hover.border.color');\n    }\n\n    .p-cascadeselect:not(.p-disabled).p-focus {\n        border-color: dt('cascadeselect.focus.border.color');\n        box-shadow: dt('cascadeselect.focus.ring.shadow');\n        outline: dt('cascadeselect.focus.ring.width') dt('cascadeselect.focus.ring.style') dt('cascadeselect.focus.ring.color');\n        outline-offset: dt('cascadeselect.focus.ring.offset');\n    }\n\n    .p-cascadeselect.p-variant-filled {\n        background: dt('cascadeselect.filled.background');\n    }\n\n    .p-cascadeselect.p-variant-filled:not(.p-disabled):hover {\n        background: dt('cascadeselect.filled.hover.background');\n    }\n\n    .p-cascadeselect.p-variant-filled.p-focus {\n        background: dt('cascadeselect.filled.focus.background');\n    }\n\n    .p-cascadeselect.p-invalid {\n        border-color: dt('cascadeselect.invalid.border.color');\n    }\n\n    .p-cascadeselect.p-disabled {\n        opacity: 1;\n        background: dt('cascadeselect.disabled.background');\n    }\n\n    .p-cascadeselect-dropdown {\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        flex-shrink: 0;\n        background: transparent;\n        color: dt('cascadeselect.dropdown.color');\n        width: dt('cascadeselect.dropdown.width');\n        border-start-end-radius: dt('border.radius.md');\n        border-end-end-radius: dt('border.radius.md');\n    }\n\n    .p-cascadeselect-clear-icon {\n        align-self: center;\n        color: dt('cascadeselect.clear.icon.color');\n        inset-inline-end: dt('cascadeselect.dropdown.width');\n    }\n\n    .p-cascadeselect-label {\n        display: block;\n        white-space: nowrap;\n        overflow: hidden;\n        flex: 1 1 auto;\n        width: 1%;\n        text-overflow: ellipsis;\n        cursor: pointer;\n        padding: dt('cascadeselect.padding.y') dt('cascadeselect.padding.x');\n        background: transparent;\n        border: 0 none;\n        outline: 0 none;\n    }\n\n    .p-cascadeselect-label.p-placeholder {\n        color: dt('cascadeselect.placeholder.color');\n    }\n\n    .p-cascadeselect.p-invalid .p-cascadeselect-label.p-placeholder {\n        color: dt('cascadeselect.invalid.placeholder.color');\n    }\n\n    .p-cascadeselect.p-disabled .p-cascadeselect-label {\n        color: dt('cascadeselect.disabled.color');\n    }\n\n    .p-cascadeselect-label-empty {\n        overflow: hidden;\n        visibility: hidden;\n    }\n\n    .p-cascadeselect-overlay {\n        background: dt('cascadeselect.overlay.background');\n        color: dt('cascadeselect.overlay.color');\n        border: 1px solid dt('cascadeselect.overlay.border.color');\n        border-radius: dt('cascadeselect.overlay.border.radius');\n        box-shadow: dt('cascadeselect.overlay.shadow');\n    }\n\n    .p-cascadeselect .p-cascadeselect-overlay {\n        min-width: 100%;\n    }\n\n    .p-cascadeselect-option-list {\n        display: none;\n        min-width: 100%;\n        position: absolute;\n        z-index: 1;\n    }\n\n    .p-cascadeselect-list {\n        min-width: 100%;\n        margin: 0;\n        padding: 0;\n        list-style-type: none;\n        padding: dt('cascadeselect.list.padding');\n        display: flex;\n        flex-direction: column;\n        gap: dt('cascadeselect.list.gap');\n    }\n\n    .p-cascadeselect-option {\n        cursor: pointer;\n        font-weight: normal;\n        white-space: nowrap;\n        border: 0 none;\n        color: dt('cascadeselect.option.color');\n        background: transparent;\n        border-radius: dt('cascadeselect.option.border.radius');\n    }\n\n    .p-cascadeselect-option-active {\n        overflow: visible;\n    }\n\n    .p-cascadeselect-option-active > .p-cascadeselect-option-content {\n        background: dt('cascadeselect.option.focus.background');\n        color: dt('cascadeselect.option.focus.color');\n    }\n\n    .p-cascadeselect-option:not(.p-cascadeselect-option-selected):not(.p-disabled).p-focus > .p-cascadeselect-option-content {\n        background: dt('cascadeselect.option.focus.background');\n        color: dt('cascadeselect.option.focus.color');\n    }\n\n    .p-cascadeselect-option:not(.p-cascadeselect-option-selected):not(.p-disabled).p-focus > .p-cascadeselect-option-content > .p-cascadeselect-group-icon-container > .p-cascadeselect-group-icon {\n        color: dt('cascadeselect.option.icon.focus.color');\n    }\n\n    .p-cascadeselect-option-selected > .p-cascadeselect-option-content {\n        background: dt('cascadeselect.option.selected.background');\n        color: dt('cascadeselect.option.selected.color');\n    }\n\n    .p-cascadeselect-option-selected.p-focus > .p-cascadeselect-option-content {\n        background: dt('cascadeselect.option.selected.focus.background');\n        color: dt('cascadeselect.option.selected.focus.color');\n    }\n\n    .p-cascadeselect-option-active > .p-cascadeselect-option-list {\n        inset-inline-start: 100%;\n        inset-block-start: 0;\n    }\n\n    .p-cascadeselect-option-content {\n        display: flex;\n        align-items: center;\n        justify-content: space-between;\n        overflow: hidden;\n        position: relative;\n        padding: dt('cascadeselect.option.padding');\n        border-radius: dt('cascadeselect.option.border.radius');\n        transition:\n            background dt('cascadeselect.transition.duration'),\n            color dt('cascadeselect.transition.duration'),\n            border-color dt('cascadeselect.transition.duration'),\n            box-shadow dt('cascadeselect.transition.duration'),\n            outline-color dt('cascadeselect.transition.duration');\n    }\n\n    .p-cascadeselect-group-icon {\n        font-size: dt('cascadeselect.option.icon.size');\n        width: dt('cascadeselect.option.icon.size');\n        height: dt('cascadeselect.option.icon.size');\n        color: dt('cascadeselect.option.icon.color');\n    }\n\n    .p-cascadeselect-group-icon:dir(rtl) {\n        transform: rotate(180deg);\n    }\n\n    .p-cascadeselect-mobile-active .p-cascadeselect-option-list {\n        position: static;\n        box-shadow: none;\n        border: 0 none;\n        padding-inline-start: dt('tieredmenu.submenu.mobile.indent');\n        padding-inline-end: 0;\n    }\n\n    .p-cascadeselect-mobile-active .p-cascadeselect-group-icon {\n        transition: transform 0.2s;\n        transform: rotate(90deg);\n    }\n\n    .p-cascadeselect-mobile-active .p-cascadeselect-option-active > .p-cascadeselect-option-content .p-cascadeselect-group-icon {\n        transform: rotate(-90deg);\n    }\n\n    .p-cascadeselect-sm .p-cascadeselect-label {\n        font-size: dt('cascadeselect.sm.font.size');\n        padding-block: dt('cascadeselect.sm.padding.y');\n        padding-inline: dt('cascadeselect.sm.padding.x');\n    }\n\n    .p-cascadeselect-sm .p-cascadeselect-dropdown .p-icon {\n        font-size: dt('cascadeselect.sm.font.size');\n        width: dt('cascadeselect.sm.font.size');\n        height: dt('cascadeselect.sm.font.size');\n    }\n\n    .p-cascadeselect-lg .p-cascadeselect-label {\n        font-size: dt('cascadeselect.lg.font.size');\n        padding-block: dt('cascadeselect.lg.padding.y');\n        padding-inline: dt('cascadeselect.lg.padding.x');\n    }\n\n    .p-cascadeselect-lg .p-cascadeselect-dropdown .p-icon {\n        font-size: dt('cascadeselect.lg.font.size');\n        width: dt('cascadeselect.lg.font.size');\n        height: dt('cascadeselect.lg.font.size');\n    }\n\n    .p-cascadeselect-fluid {\n        display: flex;\n    }\n\n    .p-cascadeselect-fluid .p-cascadeselect-label {\n        width: 1%;\n    }\n\n    .p-cascadeselect-fluid .p-cascadeselect-overlay .p-cascadeselect-overlay {\n         min-width: 12.5rem;\n    }\n";

// node_modules/primeng/fesm2022/primeng-cascadeselect.mjs
var _c0 = (a0) => ({
  processedOption: a0
});
var _c1 = (a0, a1) => ({
  $implicit: a0,
  level: a1
});
function CascadeSelectSub_ng_template_1_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CascadeSelectSub_ng_template_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CascadeSelectSub_ng_template_1_ng_container_2_ng_container_1_Template, 1, 0, "ng-container", 8);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const processedOption_r2 = ɵɵnextContext().$implicit;
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", ctx_r2.optionTemplate)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c1, processedOption_r2 == null ? null : processedOption_r2.option, ctx_r2.level));
  }
}
function CascadeSelectSub_ng_template_1_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const processedOption_r2 = ɵɵnextContext().$implicit;
    const ctx_r2 = ɵɵnextContext();
    ɵɵclassMap(ctx_r2.cx("optionText"));
    ɵɵattribute("data-pc-section", "text");
    ɵɵadvance();
    ɵɵtextInterpolate(ctx_r2.getOptionLabelToRender(processedOption_r2));
  }
}
function CascadeSelectSub_ng_template_1_span_5__svg_svg_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵnamespaceSVG();
    ɵɵelement(0, "svg", 11);
  }
}
function CascadeSelectSub_ng_template_1_span_5_2_ng_template_0_Template(rf, ctx) {
}
function CascadeSelectSub_ng_template_1_span_5_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CascadeSelectSub_ng_template_1_span_5_2_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CascadeSelectSub_ng_template_1_span_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtemplate(1, CascadeSelectSub_ng_template_1_span_5__svg_svg_1_Template, 1, 0, "svg", 9)(2, CascadeSelectSub_ng_template_1_span_5_2_Template, 1, 0, null, 10);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵclassMap(ctx_r2.cx("groupIcon"));
    ɵɵattribute("data-pc-section", "groupIcon");
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r2.groupicon);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", ctx_r2.groupicon);
  }
}
function CascadeSelectSub_ng_template_1_p_cascadeselect_sub_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-cascadeselect-sub", 12);
    ɵɵlistener("onChange", function CascadeSelectSub_ng_template_1_p_cascadeselect_sub_6_Template_p_cascadeselect_sub_onChange_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.onChange.emit($event));
    })("onFocusChange", function CascadeSelectSub_ng_template_1_p_cascadeselect_sub_6_Template_p_cascadeselect_sub_onFocusChange_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.onFocusChange.emit($event));
    })("onFocusEnterChange", function CascadeSelectSub_ng_template_1_p_cascadeselect_sub_6_Template_p_cascadeselect_sub_onFocusEnterChange_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r2 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r2.onFocusEnterChange.emit($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const processedOption_r2 = ɵɵnextContext().$implicit;
    const ctx_r2 = ɵɵnextContext();
    ɵɵclassMap(ctx_r2.cx("optionList"));
    ɵɵproperty("role", "group")("selectId", ctx_r2.selectId)("focusedOptionId", ctx_r2.focusedOptionId)("activeOptionPath", ctx_r2.activeOptionPath)("options", ctx_r2.getOptionGroupChildren(processedOption_r2))("optionLabel", ctx_r2.optionLabel)("optionValue", ctx_r2.optionValue)("level", ctx_r2.level + 1)("optionGroupLabel", ctx_r2.optionGroupLabel)("optionGroupChildren", ctx_r2.optionGroupChildren)("dirty", ctx_r2.dirty)("optionTemplate", ctx_r2.optionTemplate);
  }
}
function CascadeSelectSub_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "li", 3)(1, "div", 4);
    ɵɵlistener("click", function CascadeSelectSub_ng_template_1_Template_div_click_1_listener($event) {
      const processedOption_r2 = ɵɵrestoreView(_r1).$implicit;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.onOptionClick($event, processedOption_r2));
    })("mouseenter", function CascadeSelectSub_ng_template_1_Template_div_mouseenter_1_listener($event) {
      const processedOption_r2 = ɵɵrestoreView(_r1).$implicit;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.onOptionMouseEnter($event, processedOption_r2));
    })("mousemove", function CascadeSelectSub_ng_template_1_Template_div_mousemove_1_listener($event) {
      const processedOption_r2 = ɵɵrestoreView(_r1).$implicit;
      const ctx_r2 = ɵɵnextContext();
      return ɵɵresetView(ctx_r2.onOptionMouseMove($event, processedOption_r2));
    });
    ɵɵtemplate(2, CascadeSelectSub_ng_template_1_ng_container_2_Template, 2, 5, "ng-container", 5)(3, CascadeSelectSub_ng_template_1_ng_template_3_Template, 2, 4, "ng-template", null, 0, ɵɵtemplateRefExtractor)(5, CascadeSelectSub_ng_template_1_span_5_Template, 3, 5, "span", 6);
    ɵɵelementEnd();
    ɵɵtemplate(6, CascadeSelectSub_ng_template_1_p_cascadeselect_sub_6_Template, 1, 14, "p-cascadeselect-sub", 7);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const processedOption_r2 = ctx.$implicit;
    const i_r5 = ctx.index;
    const defaultOptionTemplate_r6 = ɵɵreference(4);
    const ctx_r2 = ɵɵnextContext();
    ɵɵclassMap(ctx_r2.cx("option", ɵɵpureFunction1(16, _c0, processedOption_r2)));
    ɵɵproperty("id", ctx_r2.getOptionId(processedOption_r2));
    ɵɵattribute("aria-level", ctx_r2.level + 1)("aria-setsize", ctx_r2.options.length)("data-pc-section", "item")("aria-label", ctx_r2.getOptionLabelToRender(processedOption_r2))("aria-selected", ctx_r2.isOptionGroup(processedOption_r2) ? void 0 : ctx_r2.isOptionSelected(processedOption_r2))("aria-posinset", i_r5 + 1);
    ɵɵadvance();
    ɵɵclassMap(ctx_r2.cx("optionContent"));
    ɵɵattribute("data-pc-section", "content");
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r2.optionTemplate)("ngIfElse", defaultOptionTemplate_r6);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ctx_r2.isOptionGroup(processedOption_r2));
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r2.isOptionGroup(processedOption_r2) && ctx_r2.isOptionActive(processedOption_r2));
  }
}
var _c2 = ["value"];
var _c3 = ["option"];
var _c4 = ["header"];
var _c5 = ["footer"];
var _c6 = ["triggericon"];
var _c7 = ["loadingicon"];
var _c8 = ["optiongroupicon"];
var _c9 = ["clearicon"];
var _c10 = ["focusInput"];
var _c11 = ["panel"];
var _c12 = ["overlay"];
var _c13 = (a0, a1) => ({
  $implicit: a0,
  placeholder: a1
});
function CascadeSelect_ng_container_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CascadeSelect_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CascadeSelect_ng_container_4_ng_container_1_Template, 1, 0, "ng-container", 13);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", ctx_r1.valueTemplate || ctx_r1._valueTemplate)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c13, ctx_r1.value, ctx_r1.placeholder));
  }
}
function CascadeSelect_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵtextInterpolate1(" ", ctx_r1.label(), " ");
  }
}
function CascadeSelect_ng_container_7__svg_svg_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵnamespaceSVG();
    ɵɵelementStart(0, "svg", 16);
    ɵɵlistener("click", function CascadeSelect_ng_container_7__svg_svg_1_Template_svg_click_0_listener($event) {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.clear($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵclassMap(ctx_r1.cx("clearIcon"));
    ɵɵattribute("data-pc-section", "clearicon")("aria-hidden", true);
  }
}
function CascadeSelect_ng_container_7_span_2_1_ng_template_0_Template(rf, ctx) {
}
function CascadeSelect_ng_container_7_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CascadeSelect_ng_container_7_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CascadeSelect_ng_container_7_span_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "span", 17);
    ɵɵlistener("click", function CascadeSelect_ng_container_7_span_2_Template_span_click_0_listener($event) {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.clear($event));
    });
    ɵɵtemplate(1, CascadeSelect_ng_container_7_span_2_1_Template, 1, 0, null, 18);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵclassMap(ctx_r1.cx("clearIcon"));
    ɵɵattribute("data-pc-section", "clearicon")("aria-hidden", true);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", ctx_r1.clearIconTemplate || ctx_r1._clearIconTemplate);
  }
}
function CascadeSelect_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CascadeSelect_ng_container_7__svg_svg_1_Template, 1, 4, "svg", 14)(2, CascadeSelect_ng_container_7_span_2_Template, 2, 5, "span", 15);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r1.clearIconTemplate && !ctx_r1._clearIconTemplate);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.clearIconTemplate || ctx_r1._clearIconTemplate);
  }
}
function CascadeSelect_ng_container_9_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CascadeSelect_ng_container_9_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CascadeSelect_ng_container_9_ng_container_1_ng_container_1_Template, 1, 0, "ng-container", 18);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", ctx_r1.loadingIconTemplate || ctx_r1._loadingIconTemplate);
  }
}
function CascadeSelect_ng_container_9_ng_container_2_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 20);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("loadingIcon"), ctx_r1.loadingIcon + "pi-spin"));
  }
}
function CascadeSelect_ng_container_9_ng_container_2_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 20);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(3);
    ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("loadingIcon"), ctx_r1.loadingIcon + " pi pi-spinner pi-spin"));
  }
}
function CascadeSelect_ng_container_9_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CascadeSelect_ng_container_9_ng_container_2_span_1_Template, 1, 2, "span", 19)(2, CascadeSelect_ng_container_9_ng_container_2_span_2_Template, 1, 2, "span", 19);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.loadingIcon);
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r1.loadingIcon);
  }
}
function CascadeSelect_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CascadeSelect_ng_container_9_ng_container_1_Template, 2, 1, "ng-container", 9)(2, CascadeSelect_ng_container_9_ng_container_2_Template, 3, 2, "ng-container", 9);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.loadingIconTemplate || ctx_r1._loadingIconTemplate);
    ɵɵadvance();
    ɵɵproperty("ngIf", !ctx_r1.loadingIconTemplate && !ctx_r1._loadingIconTemplate);
  }
}
function CascadeSelect_ng_template_10__svg_svg_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵnamespaceSVG();
    ɵɵelement(0, "svg", 23);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵclassMap(ctx_r1.cx("dropdownIcon"));
  }
}
function CascadeSelect_ng_template_10_span_1_1_ng_template_0_Template(rf, ctx) {
}
function CascadeSelect_ng_template_10_span_1_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CascadeSelect_ng_template_10_span_1_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CascadeSelect_ng_template_10_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtemplate(1, CascadeSelect_ng_template_10_span_1_1_Template, 1, 0, null, 18);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵclassMap(ctx_r1.cx("dropdownIcon"));
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", ctx_r1.triggerIconTemplate || ctx_r1._triggerIconTemplate);
  }
}
function CascadeSelect_ng_template_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CascadeSelect_ng_template_10__svg_svg_0_Template, 1, 2, "svg", 21)(1, CascadeSelect_ng_template_10_span_1_Template, 2, 3, "span", 22);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("ngIf", !ctx_r1.triggerIconTemplate && !ctx_r1._triggerIconTemplate);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r1.triggerIconTemplate || ctx_r1._triggerIconTemplate);
  }
}
function CascadeSelect_ng_template_16_2_ng_template_0_Template(rf, ctx) {
}
function CascadeSelect_ng_template_16_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CascadeSelect_ng_template_16_2_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CascadeSelect_ng_template_16_7_ng_template_0_Template(rf, ctx) {
}
function CascadeSelect_ng_template_16_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, CascadeSelect_ng_template_16_7_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function CascadeSelect_ng_template_16_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 24, 5);
    ɵɵtemplate(2, CascadeSelect_ng_template_16_2_Template, 1, 0, null, 18);
    ɵɵelementStart(3, "div")(4, "p-cascadeselect-sub", 25);
    ɵɵlistener("onChange", function CascadeSelect_ng_template_16_Template_p_cascadeselect_sub_onChange_4_listener($event) {
      ɵɵrestoreView(_r5);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onOptionClick($event));
    })("onFocusChange", function CascadeSelect_ng_template_16_Template_p_cascadeselect_sub_onFocusChange_4_listener($event) {
      ɵɵrestoreView(_r5);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onOptionMouseMove($event));
    })("onFocusEnterChange", function CascadeSelect_ng_template_16_Template_p_cascadeselect_sub_onFocusEnterChange_4_listener($event) {
      ɵɵrestoreView(_r5);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.onOptionMouseEnter($event));
    });
    ɵɵelementEnd()();
    ɵɵelementStart(5, "span", 11);
    ɵɵtext(6);
    ɵɵelementEnd();
    ɵɵtemplate(7, CascadeSelect_ng_template_16_7_Template, 1, 0, null, 18);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵclassMap(ctx_r1.cn(ctx_r1.cx("overlay"), ctx_r1.panelStyleClass));
    ɵɵproperty("ngStyle", ctx_r1.panelStyle);
    ɵɵattribute("data-pc-section", "panel");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", ctx_r1.headerTemplate || ctx_r1._headerTemplate);
    ɵɵadvance();
    ɵɵclassMap(ctx_r1.cx("listContainer"));
    ɵɵattribute("data-pc-section", "wrapper");
    ɵɵadvance();
    ɵɵproperty("options", ctx_r1.processedOptions)("selectId", ctx_r1.id)("focusedOptionId", ctx_r1.focused ? ctx_r1.focusedOptionId : void 0)("activeOptionPath", ctx_r1.activeOptionPath())("optionLabel", ctx_r1.optionLabel)("optionValue", ctx_r1.optionValue)("level", 0)("optionTemplate", ctx_r1.optionTemplate || ctx_r1._optionTemplate)("groupicon", ctx_r1.groupIconTemplate || ctx_r1.groupIconTemplate)("optionGroupLabel", ctx_r1.optionGroupLabel)("optionGroupChildren", ctx_r1.optionGroupChildren)("optionDisabled", ctx_r1.optionDisabled)("root", true)("dirty", ctx_r1.dirty)("role", "tree");
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", ctx_r1.selectedMessageText, " ");
    ɵɵadvance();
    ɵɵproperty("ngTemplateOutlet", ctx_r1.footerTemplate || ctx_r1._footerTemplate);
  }
}
var theme = (
  /*css*/
  `
    ${style}

    /* For PrimeNG */
    .p-cascadeselect.ng-invalid.ng-dirty:not(.ng-untouched):not(.ng-pristine) {
        border-color: dt('cascadeselect.invalid.border.color');
    }

    .p-cascadeselect.ng-invalid.ng-dirty:not(.ng-untouched):not(.ng-pristine) .p-cascadeselect-label.p-placeholder {
        color: dt('cascadeselect.invalid.placeholder.color');
    }
`
);
var inlineStyles = {
  root: ({
    instance
  }) => ({
    position: instance.$appendTo() === "self" ? "relative" : void 0
  })
};
var classes = {
  root: ({
    instance
  }) => ["p-cascadeselect p-component p-inputwrapper", {
    "p-cascadeselect p-component p-inputwrapper": true,
    "p-cascadeselect-clearable": instance.showClear && !instance.$disabled(),
    "p-cascadeselect-mobile": instance.queryMatches(),
    "p-disabled": instance.$disabled(),
    "p-invalid": instance.invalid(),
    "p-focus": instance.focused,
    "p-inputwrapper-filled": instance.modelValue(),
    "p-variant-filled": instance.$variant() === "filled",
    "p-inputwrapper-focus": instance.focused || instance.overlayVisible,
    "p-cascadeselect-open": instance.overlayVisible,
    "p-cascadeselect-fluid": instance.hasFluid,
    "p-cascadeselect-sm p-inputfield-sm": instance.size() === "small",
    "p-cascadeselect-lg p-inputfield-lg": instance.size() === "large"
  }],
  label: ({
    instance
  }) => ["p-cascadeselect-label", {
    "p-placeholder": instance.label() === instance.placeholder,
    "p-cascadeselect-label-empty": !instance.value && (instance.label() === "p-emptylabel" || instance.label().length === 0)
  }],
  clearIcon: "p-cascadeselect-clear-icon",
  dropdown: "p-cascadeselect-dropdown",
  loadingIcon: "p-cascadeselect-loading-icon",
  dropdownIcon: "p-cascadeselect-dropdown-icon",
  overlay: ({
    instance
  }) => ["p-cascadeselect-overlay p-component-overlay p-component", {
    "p-cascadeselect-mobile-active": instance.queryMatches()
  }],
  listContainer: "p-cascadeselect-list-container",
  list: "p-cascadeselect-list",
  option: ({
    instance,
    processedOption
  }) => ["p-cascadeselect-option", {
    "p-cascadeselect-option-group": instance.isOptionGroup(processedOption),
    "p-cascadeselect-option-active": instance.isOptionActive(processedOption),
    "p-cascadeselect-option-selected": instance.isOptionSelected(processedOption),
    "p-focus": instance.isOptionFocused(processedOption),
    "p-disabled": instance.isOptionDisabled(processedOption)
  }],
  optionContent: "p-cascadeselect-option-content",
  optionText: "p-cascadeselect-option-text",
  groupIcon: "p-cascadeselect-group-icon",
  optionList: "p-cascadeselect-list p-cascadeselect-overlay p-cascadeselect-option-list"
};
var CascadeSelectStyle = class _CascadeSelectStyle extends BaseStyle {
  name = "cascadeselect";
  theme = theme;
  classes = classes;
  inlineStyles = inlineStyles;
  static ɵfac = /* @__PURE__ */ (() => {
    let ɵCascadeSelectStyle_BaseFactory;
    return function CascadeSelectStyle_Factory(__ngFactoryType__) {
      return (ɵCascadeSelectStyle_BaseFactory || (ɵCascadeSelectStyle_BaseFactory = ɵɵgetInheritedFactory(_CascadeSelectStyle)))(__ngFactoryType__ || _CascadeSelectStyle);
    };
  })();
  static ɵprov = ɵɵdefineInjectable({
    token: _CascadeSelectStyle,
    factory: _CascadeSelectStyle.ɵfac
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CascadeSelectStyle, [{
    type: Injectable
  }], null, null);
})();
var CascadeSelectClasses;
(function(CascadeSelectClasses2) {
  CascadeSelectClasses2["root"] = "p-cascadeselect";
  CascadeSelectClasses2["label"] = "p-cascadeselect-label";
  CascadeSelectClasses2["dropdown"] = "p-cascadeselect-dropdown";
  CascadeSelectClasses2["loadingIcon"] = "p-cascadeselect-loading-icon";
  CascadeSelectClasses2["clearIcon"] = "p-cascadeselect-clear-icon";
  CascadeSelectClasses2["dropdownIcon"] = "p-cascadeselect-dropdown-icon";
  CascadeSelectClasses2["overlay"] = "p-cascadeselect-overlay";
  CascadeSelectClasses2["listContainer"] = "p-cascadeselect-list-container";
  CascadeSelectClasses2["list"] = "p-cascadeselect-list";
  CascadeSelectClasses2["item"] = "p-cascadeselect-item";
  CascadeSelectClasses2["itemContent"] = "p-cascadeselect-item-content";
  CascadeSelectClasses2["itemText"] = "p-cascadeselect-item-text";
  CascadeSelectClasses2["groupIcon"] = "p-cascadeselect-group-icon";
  CascadeSelectClasses2["itemList"] = "p-cascadeselect-item-list";
})(CascadeSelectClasses || (CascadeSelectClasses = {}));
var CASCADESELECT_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => CascadeSelect),
  multi: true
};
var CascadeSelectSub = class _CascadeSelectSub extends BaseComponent {
  cascadeselect;
  role;
  selectId;
  activeOptionPath;
  optionDisabled;
  focusedOptionId;
  options;
  optionGroupChildren;
  optionTemplate;
  groupicon;
  level = 0;
  optionLabel;
  optionValue;
  optionGroupLabel;
  dirty;
  root;
  onChange = new EventEmitter();
  onFocusChange = new EventEmitter();
  onFocusEnterChange = new EventEmitter();
  _componentStyle = inject(CascadeSelectStyle);
  get listLabel() {
    return this.config.getTranslation(TranslationKeys.ARIA)["listLabel"];
  }
  constructor(cascadeselect) {
    super();
    this.cascadeselect = cascadeselect;
  }
  ngOnInit() {
    super.ngOnInit();
    if (!this.root) {
      this.position();
    }
  }
  onOptionClick(event, processedOption) {
    this.onChange.emit({
      originalEvent: event,
      processedOption,
      isFocus: true
    });
  }
  onOptionMouseEnter(event, processedOption) {
    this.onFocusEnterChange.emit({
      originalEvent: event,
      processedOption
    });
  }
  onOptionMouseMove(event, processedOption) {
    this.onFocusChange.emit({
      originalEvent: event,
      processedOption
    });
  }
  getOptionId(processedOption) {
    return `${this.selectId}_${processedOption.key}`;
  }
  getOptionLabel(processedOption) {
    return this.optionLabel ? c(processedOption.option, this.optionLabel) : processedOption.option;
  }
  getOptionValue(processedOption) {
    return this.optionValue ? c(processedOption.option, this.optionValue) : processedOption.option;
  }
  getOptionLabelToRender(processedOption) {
    return this.isOptionGroup(processedOption) ? this.getOptionGroupLabel(processedOption) : this.getOptionLabel(processedOption);
  }
  isOptionDisabled(processedOption) {
    return this.optionDisabled ? c(processedOption.option, this.optionDisabled) : false;
  }
  getOptionGroupLabel(processedOption) {
    return this.optionGroupLabel ? c(processedOption.option, this.optionGroupLabel) : null;
  }
  getOptionGroupChildren(processedOption) {
    return processedOption.children;
  }
  isOptionGroup(processedOption) {
    return s(processedOption.children);
  }
  isOptionSelected(processedOption) {
    return k(this.cascadeselect?.modelValue(), processedOption?.option);
  }
  isOptionActive(processedOption) {
    return this.activeOptionPath.some((path) => path.key === processedOption.key);
  }
  isOptionFocused(processedOption) {
    return this.focusedOptionId === this.getOptionId(processedOption);
  }
  position() {
    const parentItem = this.el.nativeElement.parentElement;
    const containerOffset = K(parentItem);
    const viewport = h();
    const sublistWidth = this.el.nativeElement.children[0].offsetParent ? this.el.nativeElement.children[0].offsetWidth : J(this.el.nativeElement.children[0]);
    const itemOuterWidth = v(parentItem.children[0]);
    if (parseInt(containerOffset.left, 10) + itemOuterWidth + sublistWidth > viewport.width - P()) {
      this.el.nativeElement.children[0].style.left = "-200%";
    }
  }
  static ɵfac = function CascadeSelectSub_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CascadeSelectSub)(ɵɵdirectiveInject(CascadeSelect));
  };
  static ɵcmp = ɵɵdefineComponent({
    type: _CascadeSelectSub,
    selectors: [["p-cascadeSelectSub"], ["p-cascadeselect-sub"]],
    inputs: {
      role: "role",
      selectId: "selectId",
      activeOptionPath: "activeOptionPath",
      optionDisabled: "optionDisabled",
      focusedOptionId: "focusedOptionId",
      options: "options",
      optionGroupChildren: "optionGroupChildren",
      optionTemplate: "optionTemplate",
      groupicon: "groupicon",
      level: [2, "level", "level", numberAttribute],
      optionLabel: "optionLabel",
      optionValue: "optionValue",
      optionGroupLabel: "optionGroupLabel",
      dirty: [2, "dirty", "dirty", booleanAttribute],
      root: [2, "root", "root", booleanAttribute]
    },
    outputs: {
      onChange: "onChange",
      onFocusChange: "onFocusChange",
      onFocusEnterChange: "onFocusEnterChange"
    },
    features: [ɵɵProvidersFeature([CascadeSelectStyle]), ɵɵInheritDefinitionFeature],
    decls: 2,
    vars: 6,
    consts: [["defaultOptionTemplate", ""], ["aria-orientation", "horizontal"], ["ngFor", "", 3, "ngForOf"], ["role", "treeitem", 3, "id"], ["pRipple", "", 3, "click", "mouseenter", "mousemove"], [4, "ngIf", "ngIfElse"], [3, "class", 4, "ngIf"], [3, "role", "class", "selectId", "focusedOptionId", "activeOptionPath", "options", "optionLabel", "optionValue", "level", "optionGroupLabel", "optionGroupChildren", "dirty", "optionTemplate", "onChange", "onFocusChange", "onFocusEnterChange", 4, "ngIf"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["data-p-icon", "angle-right", 4, "ngIf"], [4, "ngTemplateOutlet"], ["data-p-icon", "angle-right"], [3, "onChange", "onFocusChange", "onFocusEnterChange", "role", "selectId", "focusedOptionId", "activeOptionPath", "options", "optionLabel", "optionValue", "level", "optionGroupLabel", "optionGroupChildren", "dirty", "optionTemplate"]],
    template: function CascadeSelectSub_Template(rf, ctx) {
      if (rf & 1) {
        ɵɵelementStart(0, "ul", 1);
        ɵɵtemplate(1, CascadeSelectSub_ng_template_1_Template, 7, 18, "ng-template", 2);
        ɵɵelementEnd();
      }
      if (rf & 2) {
        ɵɵclassMap(ctx.cx("list"));
        ɵɵattribute("role", ctx.role)("data-pc-section", ctx.level === 0 ? "list" : "sublist")("aria-label", ctx.listLabel);
        ɵɵadvance();
        ɵɵproperty("ngForOf", ctx.options);
      }
    },
    dependencies: [_CascadeSelectSub, CommonModule, NgForOf, NgIf, NgTemplateOutlet, Ripple, AngleRightIcon, SharedModule],
    encapsulation: 2,
    changeDetection: 0
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CascadeSelectSub, [{
    type: Component,
    args: [{
      selector: "p-cascadeSelectSub, p-cascadeselect-sub",
      standalone: true,
      imports: [CommonModule, Ripple, AngleRightIcon, SharedModule],
      template: `
        <ul [class]="cx('list')" [attr.role]="role" aria-orientation="horizontal" [attr.data-pc-section]="level === 0 ? 'list' : 'sublist'" [attr.aria-label]="listLabel">
            <ng-template ngFor let-processedOption [ngForOf]="options" let-i="index">
                <li
                    [class]="cx('option', { processedOption })"
                    role="treeitem"
                    [attr.aria-level]="level + 1"
                    [attr.aria-setsize]="options.length"
                    [attr.data-pc-section]="'item'"
                    [id]="getOptionId(processedOption)"
                    [attr.aria-label]="getOptionLabelToRender(processedOption)"
                    [attr.aria-selected]="isOptionGroup(processedOption) ? undefined : isOptionSelected(processedOption)"
                    [attr.aria-posinset]="i + 1"
                >
                    <div
                        [class]="cx('optionContent')"
                        (click)="onOptionClick($event, processedOption)"
                        (mouseenter)="onOptionMouseEnter($event, processedOption)"
                        (mousemove)="onOptionMouseMove($event, processedOption)"
                        pRipple
                        [attr.data-pc-section]="'content'"
                    >
                        <ng-container *ngIf="optionTemplate; else defaultOptionTemplate">
                            <ng-container *ngTemplateOutlet="optionTemplate; context: { $implicit: processedOption?.option, level: level }"></ng-container>
                        </ng-container>
                        <ng-template #defaultOptionTemplate>
                            <span [class]="cx('optionText')" [attr.data-pc-section]="'text'">{{ getOptionLabelToRender(processedOption) }}</span>
                        </ng-template>
                        <span [class]="cx('groupIcon')" *ngIf="isOptionGroup(processedOption)" [attr.data-pc-section]="'groupIcon'">
                            <svg data-p-icon="angle-right" *ngIf="!groupicon" />
                            <ng-template *ngTemplateOutlet="groupicon"></ng-template>
                        </span>
                    </div>
                    <p-cascadeselect-sub
                        *ngIf="isOptionGroup(processedOption) && isOptionActive(processedOption)"
                        [role]="'group'"
                        [class]="cx('optionList')"
                        [selectId]="selectId"
                        [focusedOptionId]="focusedOptionId"
                        [activeOptionPath]="activeOptionPath"
                        [options]="getOptionGroupChildren(processedOption)"
                        [optionLabel]="optionLabel"
                        [optionValue]="optionValue"
                        [level]="level + 1"
                        (onChange)="onChange.emit($event)"
                        (onFocusChange)="onFocusChange.emit($event)"
                        (onFocusEnterChange)="onFocusEnterChange.emit($event)"
                        [optionGroupLabel]="optionGroupLabel"
                        [optionGroupChildren]="optionGroupChildren"
                        [dirty]="dirty"
                        [optionTemplate]="optionTemplate"
                    >
                    </p-cascadeselect-sub>
                </li>
            </ng-template>
        </ul>
    `,
      encapsulation: ViewEncapsulation.None,
      changeDetection: ChangeDetectionStrategy.OnPush,
      providers: [CascadeSelectStyle]
    }]
  }], () => [{
    type: CascadeSelect
  }], {
    role: [{
      type: Input
    }],
    selectId: [{
      type: Input
    }],
    activeOptionPath: [{
      type: Input
    }],
    optionDisabled: [{
      type: Input
    }],
    focusedOptionId: [{
      type: Input
    }],
    options: [{
      type: Input
    }],
    optionGroupChildren: [{
      type: Input
    }],
    optionTemplate: [{
      type: Input
    }],
    groupicon: [{
      type: Input
    }],
    level: [{
      type: Input,
      args: [{
        transform: numberAttribute
      }]
    }],
    optionLabel: [{
      type: Input
    }],
    optionValue: [{
      type: Input
    }],
    optionGroupLabel: [{
      type: Input
    }],
    dirty: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    root: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    onChange: [{
      type: Output
    }],
    onFocusChange: [{
      type: Output
    }],
    onFocusEnterChange: [{
      type: Output
    }]
  });
})();
var CascadeSelect = class _CascadeSelect extends BaseEditableHolder {
  overlayService;
  /**
   * Unique identifier of the component
   * @group Props
   */
  id;
  /**
   * Text to display when the search is active. Defaults to global value in i18n translation configuration.
   * @group Props
   * @defaultValue '{0} results are available'
   */
  searchMessage;
  /**
   * Text to display when there is no data. Defaults to global value in i18n translation configuration.
   * @group Props
   */
  emptyMessage;
  /**
   * Text to be displayed in hidden accessible field when options are selected. Defaults to global value in i18n translation configuration.
   * @group Props
   * @defaultValue '{0} items selected'
   */
  selectionMessage;
  /**
   * Text to display when filtering does not return any results. Defaults to value from PrimeNG locale configuration.
   * @group Props
   * @defaultValue 'No available options'
   */
  emptySearchMessage;
  /**
   * Text to display when filtering does not return any results. Defaults to global value in i18n translation configuration.
   * @group Props
   * @defaultValue 'No selected item'
   */
  emptySelectionMessage;
  /**
   * Locale to use in searching. The default locale is the host environment's current locale.
   * @group Props
   */
  searchLocale;
  /**
   * Name of the disabled field of an option.
   * @group Props
   */
  optionDisabled;
  /**
   * Fields used when filtering the options, defaults to optionLabel.
   * @group Props
   */
  focusOnHover = true;
  /**
   * Determines if the option will be selected on focus.
   * @group Props
   */
  selectOnFocus = false;
  /**
   * Whether to focus on the first visible or selected element when the overlay panel is shown.
   * @group Props
   */
  autoOptionFocus = false;
  /**
   * Style class of the component.
   * @deprecated since v20.0.0, use `class` instead.
   * @group Props
   */
  styleClass;
  /**
   * An array of selectitems to display as the available options.
   * @group Props
   */
  options;
  /**
   * Property name or getter function to use as the label of an option.
   * @group Props
   */
  optionLabel;
  /**
   * Property name or getter function to use as the value of an option, defaults to the option itself when not defined.
   * @group Props
   */
  optionValue;
  /**
   * Property name or getter function to use as the label of an option group.
   * @group Props
   */
  optionGroupLabel;
  /**
   * Property name or getter function to retrieve the items of a group.
   * @group Props
   */
  optionGroupChildren;
  /**
   * Default text to display when no option is selected.
   * @group Props
   */
  placeholder;
  /**
   * Selected value of the component.
   * @group Props
   */
  value;
  /**
   * A property to uniquely identify an option.
   * @group Props
   */
  dataKey;
  /**
   * Identifier of the underlying input element.
   * @group Props
   */
  inputId;
  /**
   * Index of the element in tabbing order.
   * @group Props
   */
  tabindex = 0;
  /**
   * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
   * @group Props
   */
  ariaLabelledBy;
  /**
   * Label of the input for accessibility.
   * @group Props
   */
  inputLabel;
  /**
   * Defines a string that labels the input for accessibility.
   * @group Props
   */
  ariaLabel;
  /**
   * When enabled, a clear icon is displayed to clear the value.
   * @group Props
   */
  showClear = false;
  /**
   * Style class of the overlay panel.
   * @group Props
   */
  panelStyleClass;
  /**
   * Inline style of the overlay panel.
   * @group Props
   */
  panelStyle;
  /**
   * Whether to use overlay API feature. The properties of overlay API can be used like an object in it.
   * @group Props
   */
  overlayOptions;
  /**
   * When present, it specifies that the component should automatically get focus on load.
   * @group Props
   */
  autofocus;
  /**
   * Whether the dropdown is in loading state.
   * @group Props
   */
  loading = false;
  /**
   * Icon to display in loading state.
   * @group Props
   */
  loadingIcon;
  /**
   * The breakpoint to define the maximum width boundary.
   * @group Props
   */
  breakpoint = "960px";
  /**
   * Specifies the size of the component.
   * @defaultValue undefined
   * @group Props
   */
  size = input(...ngDevMode ? [void 0, {
    debugName: "size"
  }] : []);
  /**
   * Specifies the input variant of the component.
   * @defaultValue undefined
   * @group Props
   */
  variant = input(...ngDevMode ? [void 0, {
    debugName: "variant"
  }] : []);
  /**
   * Spans 100% width of the container when enabled.
   * @defaultValue undefined
   * @group Props
   */
  fluid = input(void 0, ...ngDevMode ? [{
    debugName: "fluid",
    transform: booleanAttribute
  }] : [{
    transform: booleanAttribute
  }]);
  /**
   * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
   * @defaultValue 'self'
   * @group Props
   */
  appendTo = input(void 0, ...ngDevMode ? [{
    debugName: "appendTo"
  }] : []);
  /**
   * Callback to invoke on value change.
   * @param {CascadeSelectChangeEvent} event - Custom change event.
   * @group Emits
   */
  onChange = new EventEmitter();
  /**
   * Callback to invoke when a group changes.
   * @param {Event} event - Browser event.
   * @group Emits
   */
  onGroupChange = new EventEmitter();
  /**
   * Callback to invoke when the overlay is shown.
   * @param {CascadeSelectShowEvent} event - Custom overlay show event.
   * @group Emits
   */
  onShow = new EventEmitter();
  /**
   * Callback to invoke when the overlay is hidden.
   * @param {CascadeSelectHideEvent} event - Custom overlay hide event.
   * @group Emits
   */
  onHide = new EventEmitter();
  /**
   * Callback to invoke when the clear token is clicked.
   * @group Emits
   */
  onClear = new EventEmitter();
  /**
   * Callback to invoke before overlay is shown.
   * @param {CascadeSelectBeforeShowEvent} event - Custom overlay show event.
   * @group Emits
   */
  onBeforeShow = new EventEmitter();
  /**
   * Callback to invoke before overlay is hidden.
   * @param {CascadeSelectBeforeHideEvent} event - Custom overlay hide event.
   * @group Emits
   */
  onBeforeHide = new EventEmitter();
  /**
   * Callback to invoke when input receives focus.
   * @param {FocusEvent} event - Focus event.
   * @group Emits
   */
  onFocus = new EventEmitter();
  /**
   * Callback to invoke when input loses focus.
   * @param {FocusEvent} event - Focus event.
   * @group Emits
   */
  onBlur = new EventEmitter();
  focusInputViewChild;
  panelViewChild;
  overlayViewChild;
  /**
   * Content template for displaying the selected value.
   * @group Templates
   */
  valueTemplate;
  /**
   * Content template for customizing the option display.
   * @group Templates
   */
  optionTemplate;
  /**
   * Content template for customizing the header.
   * @group Templates
   */
  headerTemplate;
  /**
   * Content template for customizing the footer.
   * @group Templates
   */
  footerTemplate;
  /**
   * Content template for customizing the trigger icon.
   * @group Templates
   */
  triggerIconTemplate;
  /**
   * Content template for customizing the loading icon.
   * @group Templates
   */
  loadingIconTemplate;
  /**
   * Content template for customizing the group icon.
   * @group Templates
   */
  groupIconTemplate;
  /**
   * Content template for customizing the clear icon.
   * @group Templates
   */
  clearIconTemplate;
  _valueTemplate;
  _optionTemplate;
  _headerTemplate;
  _footerTemplate;
  _triggerIconTemplate;
  _loadingIconTemplate;
  _groupIconTemplate;
  _clearIconTemplate;
  selectionPath = null;
  focused = false;
  overlayVisible = false;
  clicked = false;
  dirty = false;
  searchValue;
  searchTimeout;
  focusedOptionInfo = signal({
    index: -1,
    level: 0,
    parentKey: ""
  }, ...ngDevMode ? [{
    debugName: "focusedOptionInfo"
  }] : []);
  activeOptionPath = signal([], ...ngDevMode ? [{
    debugName: "activeOptionPath"
  }] : []);
  processedOptions = [];
  _componentStyle = inject(CascadeSelectStyle);
  initialized = false;
  $variant = computed(() => this.variant() || this.config.inputStyle() || this.config.inputVariant(), ...ngDevMode ? [{
    debugName: "$variant"
  }] : []);
  $appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), ...ngDevMode ? [{
    debugName: "$appendTo"
  }] : []);
  pcFluid = inject(Fluid, {
    optional: true,
    host: true,
    skipSelf: true
  });
  get hasFluid() {
    return this.fluid() ?? !!this.pcFluid;
  }
  onHostClick(event) {
    this.onContainerClick(event);
  }
  get focusedOptionId() {
    return this.focusedOptionInfo().index !== -1 ? `${this.id}${s(this.focusedOptionInfo().parentKey) ? "_" + this.focusedOptionInfo().parentKey : ""}_${this.focusedOptionInfo().index}` : null;
  }
  get searchResultMessageText() {
    return s(this.visibleOptions()) ? this.searchMessageText.replaceAll("{0}", this.visibleOptions().length) : this.emptySearchMessageText;
  }
  get searchMessageText() {
    return this.searchMessage || this.config.translation.searchMessage || "";
  }
  get emptySearchMessageText() {
    return this.emptySearchMessage || this.config.translation.emptySearchMessage || "";
  }
  get emptyMessageText() {
    return this.emptyMessage || this.config.translation.emptyMessage || "";
  }
  get selectionMessageText() {
    return this.selectionMessage || this.config.translation.selectionMessage || "";
  }
  get emptySelectionMessageText() {
    return this.emptySelectionMessage || this.config.translation.emptySelectionMessage || "";
  }
  get selectedMessageText() {
    return this.hasSelectedOption() ? this.selectionMessageText.replaceAll("{0}", "1") : this.emptySelectionMessageText;
  }
  visibleOptions = computed(() => {
    const processedOption = this.activeOptionPath().find((p) => p.key === this.focusedOptionInfo().parentKey);
    return processedOption ? processedOption.children : this.processedOptions;
  }, ...ngDevMode ? [{
    debugName: "visibleOptions"
  }] : []);
  label = computed(() => {
    const label = this.placeholder || "p-emptylabel";
    if (this.hasSelectedOption()) {
      const activeOptionPath = this.findOptionPathByValue(this.modelValue(), null);
      const processedOption = s(activeOptionPath) ? activeOptionPath[activeOptionPath.length - 1] : null;
      return processedOption ? this.getOptionLabel(processedOption.option) : label;
    }
    return label;
  }, ...ngDevMode ? [{
    debugName: "label"
  }] : []);
  get _label() {
    const label = this.placeholder || "p-emptylabel";
    if (this.hasSelectedOption()) {
      const activeOptionPath = this.findOptionPathByValue(this.modelValue(), null);
      const processedOption = s(activeOptionPath) ? activeOptionPath[activeOptionPath.length - 1] : null;
      return processedOption ? this.getOptionLabel(processedOption.option) : label;
    }
    return label;
  }
  templates;
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "value":
          this._valueTemplate = item.template;
          break;
        case "option":
          this._optionTemplate = item.template;
          break;
        case "header":
          this._headerTemplate = item.template;
          break;
        case "footer":
          this._footerTemplate = item.template;
          break;
        case "triggericon":
          this._triggerIconTemplate = item.template;
          break;
        case "loadingicon":
          this._loadingIconTemplate = item.template;
          break;
        case "clearicon":
          this._clearIconTemplate = item.template;
          break;
        case "optiongroupicon":
          this._groupIconTemplate = item.template;
          break;
      }
    });
  }
  ngOnChanges(changes) {
    super.ngOnChanges(changes);
    if (changes.options) {
      this.processedOptions = this.createProcessedOptions(changes.options.currentValue || []);
      this.updateModel(null);
    }
  }
  hasSelectedOption() {
    return s(this.modelValue());
  }
  createProcessedOptions(options, level = 0, parent = {}, parentKey = "") {
    const processedOptions = [];
    options && options.forEach((option, index) => {
      const key = (parentKey !== "" ? parentKey + "_" : "") + index;
      const newOption = {
        option,
        index,
        level,
        key,
        parent,
        parentKey
      };
      newOption["children"] = this.createProcessedOptions(this.getOptionGroupChildren(option, level), level + 1, newOption, key);
      processedOptions.push(newOption);
    });
    return processedOptions;
  }
  onInputFocus(event) {
    if (this.$disabled()) {
      return;
    }
    this.focused = true;
    this.onFocus.emit(event);
  }
  onInputBlur(event) {
    this.focused = false;
    this.focusedOptionInfo.set({
      indeX: -1,
      level: 0,
      parentKey: ""
    });
    this.searchValue = "";
    this.onModelTouched();
    this.onBlur.emit(event);
  }
  onInputKeyDown(event) {
    if (this.$disabled() || this.loading) {
      event.preventDefault();
      return;
    }
    const metaKey = event.metaKey || event.ctrlKey;
    switch (event.code) {
      case "ArrowDown":
        this.onArrowDownKey(event);
        break;
      case "ArrowUp":
        this.onArrowUpKey(event);
        break;
      case "ArrowLeft":
        this.onArrowLeftKey(event);
        break;
      case "ArrowRight":
        this.onArrowRightKey(event);
        break;
      case "Home":
        this.onHomeKey(event);
        break;
      case "End":
        this.onEndKey(event);
        break;
      case "Space":
        this.onSpaceKey(event);
        break;
      case "Enter":
      case "NumpadEnter":
        this.onEnterKey(event);
        break;
      case "Escape":
        this.onEscapeKey(event);
        break;
      case "Tab":
        this.onTabKey(event);
        break;
      case "Backspace":
        this.onBackspaceKey(event);
        break;
      case "PageDown":
      case "PageUp":
      case "ShiftLeft":
      case "ShiftRight":
        break;
      default:
        if (!metaKey && j(event.key)) {
          !this.overlayVisible && this.show();
          this.searchOptions(event, event.key);
        }
        break;
    }
    this.clicked = false;
  }
  onArrowDownKey(event) {
    if (!this.overlayVisible) {
      this.show();
    } else {
      const optionIndex = this.focusedOptionInfo().index !== -1 ? this.findNextOptionIndex(this.focusedOptionInfo().index) : this.clicked ? this.findFirstOptionIndex() : this.findFirstFocusedOptionIndex();
      this.changeFocusedOptionIndex(event, optionIndex, true);
    }
    event.preventDefault();
  }
  onArrowUpKey(event) {
    if (event.altKey) {
      if (this.focusedOptionInfo().index !== -1) {
        const processedOption = this.visibleOptions[this.focusedOptionInfo().index];
        const grouped = this.isProccessedOptionGroup(processedOption);
        !grouped && this.onOptionChange({
          originalEvent: event,
          processedOption
        });
      }
      this.overlayVisible && this.hide();
      event.preventDefault();
    } else {
      const optionIndex = this.focusedOptionInfo().index !== -1 ? this.findPrevOptionIndex(this.focusedOptionInfo().index) : this.clicked ? this.findLastOptionIndex() : this.findLastFocusedOptionIndex();
      this.changeFocusedOptionIndex(event, optionIndex, true);
      !this.overlayVisible && this.show();
      event.preventDefault();
    }
  }
  onArrowLeftKey(event) {
    if (this.overlayVisible) {
      const processedOption = this.visibleOptions()[this.focusedOptionInfo().index];
      const parentOption = this.activeOptionPath().find((p) => p.key === processedOption.parentKey);
      const matched = this.focusedOptionInfo().parentKey === "" || parentOption && parentOption.key === this.focusedOptionInfo().parentKey;
      const root = a(processedOption.parent);
      if (matched) {
        const activeOptionPath = this.activeOptionPath().filter((p) => p.parentKey !== this.focusedOptionInfo().parentKey);
        this.activeOptionPath.set(activeOptionPath);
      }
      if (!root) {
        this.focusedOptionInfo.set({
          index: -1,
          parentKey: parentOption ? parentOption.parentKey : ""
        });
        this.searchValue = "";
        this.onArrowDownKey(event);
      }
      event.preventDefault();
    }
  }
  onArrowRightKey(event) {
    if (this.overlayVisible) {
      const processedOption = this.visibleOptions()[this.focusedOptionInfo().index];
      const grouped = this.isProccessedOptionGroup(processedOption);
      if (grouped) {
        const matched = this.activeOptionPath().some((p) => processedOption.key === p.key);
        if (matched) {
          this.focusedOptionInfo.set({
            index: -1,
            parentKey: processedOption.key
          });
          this.searchValue = "";
          this.onArrowDownKey(event);
        } else {
          this.onOptionChange({
            originalEvent: event,
            processedOption
          });
        }
      }
      event.preventDefault();
    }
  }
  onHomeKey(event) {
    this.changeFocusedOptionIndex(event, this.findFirstOptionIndex());
    !this.overlayVisible && this.show();
    event.preventDefault();
  }
  onEndKey(event) {
    this.changeFocusedOptionIndex(event, this.findLastOptionIndex());
    !this.overlayVisible && this.show();
    event.preventDefault();
  }
  onEnterKey(event) {
    if (!this.overlayVisible) {
      this.focusedOptionInfo.set(__spreadProps(__spreadValues({}, this.focusedOptionInfo()), {
        index: -1
      }));
      this.onArrowDownKey(event);
    } else {
      if (this.focusedOptionInfo().index !== -1) {
        const processedOption = this.visibleOptions()[this.focusedOptionInfo().index];
        const grouped = this.isProccessedOptionGroup(processedOption);
        this.onOptionClick({
          originalEvent: event,
          processedOption
        });
        !grouped && this.hide();
      }
    }
    event.preventDefault();
  }
  onSpaceKey(event) {
    this.onEnterKey(event);
  }
  onEscapeKey(event) {
    this.overlayVisible && this.hide(event, true);
    event.preventDefault();
  }
  onTabKey(event) {
    if (this.focusedOptionInfo().index !== -1) {
      const processedOption = this.visibleOptions()[this.focusedOptionInfo().index];
      const grouped = this.isProccessedOptionGroup(processedOption);
      !grouped && this.onOptionChange({
        originalEvent: event,
        processedOption
      });
    }
    this.overlayVisible && this.hide();
  }
  onBackspaceKey(event) {
    if (s(this.modelValue()) && this.showClear) {
      this.clear();
    }
    event.stopPropagation();
  }
  equalityKey() {
    return this.optionValue ? void 0 : this.dataKey;
  }
  updateModel(value, event) {
    this.value = value;
    this.onModelChange(value);
    this.writeModelValue(value);
    if (this.initialized) {
      this.onChange.emit({
        originalEvent: event,
        value
      });
    }
  }
  autoUpdateModel() {
    if (this.selectOnFocus && this.autoOptionFocus && !this.hasSelectedOption()) {
      this.focusedOptionInfo().index = this.findFirstFocusedOptionIndex();
      this.onOptionChange({
        originalEvent: null,
        processedOption: this.visibleOptions()[this.focusedOptionInfo().index],
        isHide: false
      });
      !this.overlayVisible && this.focusedOptionInfo.set({
        index: -1,
        level: 0,
        parentKey: ""
      });
    }
  }
  scrollInView(index = -1) {
    const id = index !== -1 ? `${this.id}_${index}` : this.focusedOptionId;
    const element = z(this.panelViewChild?.nativeElement, `li[id="${id}"]`);
    if (element) {
      element.scrollIntoView && element.scrollIntoView({
        block: "nearest",
        inline: "start"
      });
    }
  }
  changeFocusedOptionIndex(event, index, preventSelection) {
    const focusedOptionInfo = this.focusedOptionInfo();
    if (focusedOptionInfo.index !== index) {
      this.focusedOptionInfo.set(__spreadProps(__spreadValues({}, focusedOptionInfo), {
        index
      }));
      this.scrollInView();
      if (this.focusOnHover) {
        this.onOptionClick({
          originalEvent: event,
          processedOption: this.visibleOptions()[index],
          isHide: false,
          preventSelection
        });
      }
      if (this.selectOnFocus) {
        this.onOptionChange({
          originalEvent: event,
          processedOption: this.visibleOptions()[index],
          isHide: false
        });
      }
    }
  }
  matchMediaListener;
  onOptionSelect(event) {
    const {
      originalEvent,
      value,
      isHide
    } = event;
    const newValue = this.getOptionValue(value);
    const activeOptionPath = this.activeOptionPath();
    activeOptionPath.forEach((p) => p.selected = true);
    this.activeOptionPath.set(activeOptionPath);
    this.updateModel(newValue, originalEvent);
    isHide && this.hide(event, true);
  }
  onOptionGroupSelect(event) {
    this.dirty = true;
    this.onGroupChange.emit(event);
  }
  onContainerClick(event) {
    if (this.$disabled() || this.loading) {
      return;
    }
    if (!this.overlayViewChild?.el?.nativeElement?.contains(event.target)) {
      if (this.overlayVisible) {
        this.hide();
      } else {
        this.show();
      }
      this.focusInputViewChild?.nativeElement.focus();
    }
    this.clicked = true;
  }
  isOptionMatched(processedOption) {
    return this.isValidOption(processedOption) && this.getProccessedOptionLabel(processedOption).toLocaleLowerCase(this.searchLocale).startsWith(this.searchValue?.toLocaleLowerCase(this.searchLocale));
  }
  isOptionDisabled(option) {
    return this.optionDisabled ? c(option, this.optionDisabled) : false;
  }
  isValidOption(processedOption) {
    return !!processedOption && !this.isOptionDisabled(processedOption.option);
  }
  isValidSelectedOption(processedOption) {
    return this.isValidOption(processedOption) && this.isSelected(processedOption);
  }
  isSelected(processedOption) {
    return this.activeOptionPath().some((p) => p.key === processedOption.key);
  }
  findOptionPathByValue(value, processedOptions, level = 0) {
    processedOptions = processedOptions || level === 0 && this.processedOptions;
    if (!processedOptions) return null;
    if (a(value)) return [];
    for (let i = 0; i < processedOptions.length; i++) {
      const processedOption = processedOptions[i];
      if (k(value, this.getOptionValue(processedOption.option), this.equalityKey())) {
        return [processedOption];
      }
      const matchedOptions = this.findOptionPathByValue(value, processedOption.children, level + 1);
      if (matchedOptions) {
        matchedOptions.unshift(processedOption);
        return matchedOptions;
      }
    }
  }
  findFirstOptionIndex() {
    return this.visibleOptions().findIndex((processedOption) => this.isValidOption(processedOption));
  }
  findLastOptionIndex() {
    return M(this.visibleOptions(), (processedOption) => this.isValidOption(processedOption));
  }
  findNextOptionIndex(index) {
    const matchedOptionIndex = index < this.visibleOptions().length - 1 ? this.visibleOptions().slice(index + 1).findIndex((processedOption) => this.isValidOption(processedOption)) : -1;
    return matchedOptionIndex > -1 ? matchedOptionIndex + index + 1 : index;
  }
  findPrevOptionIndex(index) {
    const matchedOptionIndex = index > 0 ? M(this.visibleOptions().slice(0, index), (processedOption) => this.isValidOption(processedOption)) : -1;
    return matchedOptionIndex > -1 ? matchedOptionIndex : index;
  }
  findSelectedOptionIndex() {
    return this.visibleOptions().findIndex((processedOption) => this.isValidSelectedOption(processedOption));
  }
  findFirstFocusedOptionIndex() {
    const selectedIndex = this.findSelectedOptionIndex();
    return selectedIndex < 0 ? this.findFirstOptionIndex() : selectedIndex;
  }
  findLastFocusedOptionIndex() {
    const selectedIndex = this.findSelectedOptionIndex();
    return selectedIndex < 0 ? this.findLastOptionIndex() : selectedIndex;
  }
  searchOptions(event, char) {
    this.searchValue = (this.searchValue || "") + char;
    let optionIndex = -1;
    let matched = false;
    const focusedOptionInfo = this.focusedOptionInfo();
    if (focusedOptionInfo.index !== -1) {
      optionIndex = this.visibleOptions().slice(focusedOptionInfo.index).findIndex((processedOption) => this.isOptionMatched(processedOption));
      optionIndex = optionIndex === -1 ? this.visibleOptions().slice(0, focusedOptionInfo.index).findIndex((processedOption) => this.isOptionMatched(processedOption)) : optionIndex + focusedOptionInfo.index;
    } else {
      optionIndex = this.visibleOptions().findIndex((processedOption) => this.isOptionMatched(processedOption));
    }
    if (optionIndex !== -1) {
      matched = true;
    }
    if (optionIndex === -1 && focusedOptionInfo.index === -1) {
      optionIndex = this.findFirstFocusedOptionIndex();
    }
    if (optionIndex !== -1) {
      this.changeFocusedOptionIndex(event, optionIndex);
    }
    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout);
    }
    this.searchTimeout = setTimeout(() => {
      this.searchValue = "";
      this.searchTimeout = null;
    }, 500);
    return matched;
  }
  hide(event, isFocus = false) {
    const _hide = () => {
      this.overlayVisible = false;
      this.clicked = false;
      this.activeOptionPath.set([]);
      this.focusedOptionInfo.set({
        index: -1,
        level: 0,
        parentKey: ""
      });
      isFocus && bt(this.focusInputViewChild?.nativeElement);
      this.onHide.emit(event);
      this.cd.markForCheck();
    };
    setTimeout(() => {
      _hide();
    }, 0);
  }
  show(event, isFocus = false) {
    this.onShow.emit(event);
    this.overlayVisible = true;
    const activeOptionPath = this.hasSelectedOption() ? this.findOptionPathByValue(this.modelValue()) : this.activeOptionPath();
    this.activeOptionPath.set(activeOptionPath);
    let focusedOptionInfo;
    if (this.hasSelectedOption() && s(this.activeOptionPath())) {
      const processedOption = this.activeOptionPath()[this.activeOptionPath().length - 1];
      focusedOptionInfo = {
        index: processedOption.index,
        level: processedOption.level,
        parentKey: processedOption.parentKey
      };
    } else {
      focusedOptionInfo = {
        index: this.autoOptionFocus ? this.findFirstFocusedOptionIndex() : this.findSelectedOptionIndex(),
        level: 0,
        parentKey: ""
      };
    }
    this.focusedOptionInfo.set(focusedOptionInfo);
    isFocus && bt(this.focusInputViewChild?.nativeElement);
  }
  clear(event) {
    if (s(this.modelValue()) && this.showClear) {
      this.updateModel(null);
      this.focusedOptionInfo.set({
        index: -1,
        level: 0,
        parentKey: ""
      });
      this.activeOptionPath.set([]);
      this.onClear.emit(event);
    }
    event && event.stopPropagation();
  }
  getOptionLabel(option) {
    return this.optionLabel ? c(option, this.optionLabel) : option;
  }
  getOptionValue(option) {
    return this.optionValue ? c(option, this.optionValue) : option;
  }
  getOptionGroupLabel(optionGroup) {
    return this.optionGroupLabel ? c(optionGroup, this.optionGroupLabel) : null;
  }
  getOptionGroupChildren(optionGroup, level) {
    return c(optionGroup, this.optionGroupChildren?.[level]);
  }
  isOptionGroup(option, level) {
    return Object.prototype.hasOwnProperty.call(option, this.optionGroupChildren?.[level]);
  }
  isProccessedOptionGroup(processedOption) {
    return s(processedOption?.children);
  }
  getProccessedOptionLabel(processedOption) {
    const grouped = this.isProccessedOptionGroup(processedOption);
    return grouped ? this.getOptionGroupLabel(processedOption.option) : this.getOptionLabel(processedOption.option);
  }
  constructor(overlayService) {
    super();
    this.overlayService = overlayService;
    effect(() => {
      const activeOptionPath = this.activeOptionPath();
      if (s(activeOptionPath)) {
        this.overlayViewChild?.alignOverlay();
      }
    });
  }
  query;
  queryMatches = signal(false, ...ngDevMode ? [{
    debugName: "queryMatches"
  }] : []);
  mobileActive = signal(false, ...ngDevMode ? [{
    debugName: "mobileActive"
  }] : []);
  onOptionChange(event) {
    const {
      processedOption,
      type
    } = event;
    if (a(processedOption)) return;
    const {
      index,
      key,
      level,
      parentKey,
      children
    } = processedOption;
    const grouped = s(children);
    const activeOptionPath = this.activeOptionPath().filter((p) => p.parentKey !== parentKey && p.parentKey !== key);
    this.focusedOptionInfo.set({
      index,
      level,
      parentKey
    });
    if (type == "hover" && this.queryMatches()) {
      return;
    }
    if (grouped) {
      activeOptionPath.push(processedOption);
    }
    this.activeOptionPath.set([...activeOptionPath]);
  }
  onOptionClick(event) {
    const {
      originalEvent,
      processedOption,
      isFocus,
      isHide,
      preventSelection
    } = event;
    const {
      index,
      key,
      level,
      parentKey
    } = processedOption;
    const grouped = this.isProccessedOptionGroup(processedOption);
    const selected = this.isSelected(processedOption);
    if (selected) {
      const activeOptionPath = this.activeOptionPath().filter((p) => key !== p.key && key.startsWith(p.key));
      this.activeOptionPath.set([...activeOptionPath]);
      this.focusedOptionInfo.set({
        index,
        level,
        parentKey
      });
    } else {
      if (grouped) {
        this.onOptionChange(event);
        this.onOptionGroupSelect({
          originalEvent,
          value: processedOption.option,
          isFocus: false
        });
      } else {
        const activeOptionPath = this.activeOptionPath().filter((p) => p.parentKey !== parentKey);
        activeOptionPath.push(processedOption);
        this.focusedOptionInfo.set({
          index,
          level,
          parentKey
        });
        if (!preventSelection || processedOption?.children.length !== 0) {
          this.activeOptionPath.set([...activeOptionPath]);
          this.onOptionSelect({
            originalEvent,
            value: processedOption.option,
            isHide: isFocus
          });
        }
      }
    }
    isFocus && bt(this.focusInputViewChild?.nativeElement);
  }
  onOptionMouseEnter(event) {
    if (this.focusOnHover) {
      if (this.dirty || !this.dirty && s(this.modelValue())) {
        this.onOptionChange(__spreadProps(__spreadValues({}, event), {
          type: "hover"
        }));
      } else if (!this.dirty && event.processedOption.level === 0) {
        this.onOptionClick(__spreadProps(__spreadValues({}, event), {
          type: "hover"
        }));
      }
    }
  }
  onOptionMouseMove(event) {
    if (this.focused && this.focusOnHover) {
      this.changeFocusedOptionIndex(event, event.processedOption.index);
    }
  }
  ngOnInit() {
    super.ngOnInit();
    this.id = this.id || s2("pn_id_");
    this.autoUpdateModel();
    this.bindMatchMediaListener();
  }
  ngAfterViewInit() {
    super.ngAfterViewInit();
    this.initialized = true;
  }
  bindMatchMediaListener() {
    if (!this.matchMediaListener) {
      const window = this.document.defaultView;
      if (window && window.matchMedia) {
        const query = window.matchMedia(`(max-width: ${this.breakpoint})`);
        this.query = query;
        this.queryMatches.set(query?.matches);
        this.matchMediaListener = () => {
          this.queryMatches.set(query?.matches);
          this.mobileActive.set(false);
        };
        this.query.addEventListener("change", this.matchMediaListener);
      }
    }
  }
  unbindMatchMediaListener() {
    if (this.matchMediaListener) {
      this.query.removeEventListener("change", this.matchMediaListener);
      this.matchMediaListener = null;
    }
  }
  onOverlayAnimationDone(event) {
    switch (event.toState) {
      case "void":
        this.dirty = false;
        break;
    }
  }
  /**
   * @override
   *
   * @see {@link BaseEditableHolder.writeControlValue}
   * Writes the value to the control.
   */
  writeControlValue(value, setModelValue) {
    this.value = value;
    setModelValue(value);
    this.cd.markForCheck();
  }
  ngOnDestroy() {
    if (this.matchMediaListener) {
      this.unbindMatchMediaListener();
    }
  }
  static ɵfac = function CascadeSelect_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CascadeSelect)(ɵɵdirectiveInject(OverlayService));
  };
  static ɵcmp = ɵɵdefineComponent({
    type: _CascadeSelect,
    selectors: [["p-cascadeSelect"], ["p-cascadeselect"], ["p-cascade-select"]],
    contentQueries: function CascadeSelect_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuery(dirIndex, _c2, 4);
        ɵɵcontentQuery(dirIndex, _c3, 4);
        ɵɵcontentQuery(dirIndex, _c4, 4);
        ɵɵcontentQuery(dirIndex, _c5, 4);
        ɵɵcontentQuery(dirIndex, _c6, 4);
        ɵɵcontentQuery(dirIndex, _c7, 4);
        ɵɵcontentQuery(dirIndex, _c8, 4);
        ɵɵcontentQuery(dirIndex, _c9, 4);
        ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
      }
      if (rf & 2) {
        let _t;
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.valueTemplate = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.optionTemplate = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.headerTemplate = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.footerTemplate = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.triggerIconTemplate = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.loadingIconTemplate = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.groupIconTemplate = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.clearIconTemplate = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
      }
    },
    viewQuery: function CascadeSelect_Query(rf, ctx) {
      if (rf & 1) {
        ɵɵviewQuery(_c10, 5);
        ɵɵviewQuery(_c11, 5);
        ɵɵviewQuery(_c12, 5);
      }
      if (rf & 2) {
        let _t;
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.focusInputViewChild = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.panelViewChild = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.overlayViewChild = _t.first);
      }
    },
    hostVars: 6,
    hostBindings: function CascadeSelect_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("click", function CascadeSelect_click_HostBindingHandler($event) {
          return ctx.onHostClick($event);
        });
      }
      if (rf & 2) {
        ɵɵattribute("data-pc-name", "cascadeselect")("data-pc-section", "root");
        ɵɵstyleMap(ctx.sx("root"));
        ɵɵclassMap(ctx.cn(ctx.cx("root"), ctx.styleClass));
      }
    },
    inputs: {
      id: "id",
      searchMessage: "searchMessage",
      emptyMessage: "emptyMessage",
      selectionMessage: "selectionMessage",
      emptySearchMessage: "emptySearchMessage",
      emptySelectionMessage: "emptySelectionMessage",
      searchLocale: "searchLocale",
      optionDisabled: "optionDisabled",
      focusOnHover: [2, "focusOnHover", "focusOnHover", booleanAttribute],
      selectOnFocus: [2, "selectOnFocus", "selectOnFocus", booleanAttribute],
      autoOptionFocus: [2, "autoOptionFocus", "autoOptionFocus", booleanAttribute],
      styleClass: "styleClass",
      options: "options",
      optionLabel: "optionLabel",
      optionValue: "optionValue",
      optionGroupLabel: "optionGroupLabel",
      optionGroupChildren: "optionGroupChildren",
      placeholder: "placeholder",
      value: "value",
      dataKey: "dataKey",
      inputId: "inputId",
      tabindex: [2, "tabindex", "tabindex", numberAttribute],
      ariaLabelledBy: "ariaLabelledBy",
      inputLabel: "inputLabel",
      ariaLabel: "ariaLabel",
      showClear: [2, "showClear", "showClear", booleanAttribute],
      panelStyleClass: "panelStyleClass",
      panelStyle: "panelStyle",
      overlayOptions: "overlayOptions",
      autofocus: [2, "autofocus", "autofocus", booleanAttribute],
      loading: [2, "loading", "loading", booleanAttribute],
      loadingIcon: "loadingIcon",
      breakpoint: "breakpoint",
      size: [1, "size"],
      variant: [1, "variant"],
      fluid: [1, "fluid"],
      appendTo: [1, "appendTo"]
    },
    outputs: {
      onChange: "onChange",
      onGroupChange: "onGroupChange",
      onShow: "onShow",
      onHide: "onHide",
      onClear: "onClear",
      onBeforeShow: "onBeforeShow",
      onBeforeHide: "onBeforeHide",
      onFocus: "onFocus",
      onBlur: "onBlur"
    },
    features: [ɵɵProvidersFeature([CASCADESELECT_VALUE_ACCESSOR, CascadeSelectStyle]), ɵɵInheritDefinitionFeature, ɵɵNgOnChangesFeature],
    decls: 18,
    vars: 33,
    consts: [["focusInput", ""], ["defaultValueTemplate", ""], ["elseBlock", ""], ["overlay", ""], ["content", ""], ["panel", ""], [1, "p-hidden-accessible"], ["readonly", "", "type", "text", "role", "combobox", 3, "focus", "blur", "keydown", "pAutoFocus"], [4, "ngIf", "ngIfElse"], [4, "ngIf"], ["role", "button", "aria-haspopup", "listbox"], ["role", "status", "aria-live", "polite", 1, "p-hidden-accessible"], [3, "visibleChange", "onAnimationDone", "onBeforeShow", "onShow", "onBeforeHide", "onHide", "hostAttrSelector", "visible", "options", "target", "appendTo"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["data-p-icon", "times", 3, "class", "click", 4, "ngIf"], [3, "class", "click", 4, "ngIf"], ["data-p-icon", "times", 3, "click"], [3, "click"], [4, "ngTemplateOutlet"], ["aria-hidden", "true", 3, "class", 4, "ngIf"], ["aria-hidden", "true"], ["data-p-icon", "chevron-down", 3, "class", 4, "ngIf"], [3, "class", 4, "ngIf"], ["data-p-icon", "chevron-down"], [3, "ngStyle"], [3, "onChange", "onFocusChange", "onFocusEnterChange", "options", "selectId", "focusedOptionId", "activeOptionPath", "optionLabel", "optionValue", "level", "optionTemplate", "groupicon", "optionGroupLabel", "optionGroupChildren", "optionDisabled", "root", "dirty", "role"]],
    template: function CascadeSelect_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = ɵɵgetCurrentView();
        ɵɵelementStart(0, "div", 6)(1, "input", 7, 0);
        ɵɵlistener("focus", function CascadeSelect_Template_input_focus_1_listener($event) {
          ɵɵrestoreView(_r1);
          return ɵɵresetView(ctx.onInputFocus($event));
        })("blur", function CascadeSelect_Template_input_blur_1_listener($event) {
          ɵɵrestoreView(_r1);
          return ɵɵresetView(ctx.onInputBlur($event));
        })("keydown", function CascadeSelect_Template_input_keydown_1_listener($event) {
          ɵɵrestoreView(_r1);
          return ɵɵresetView(ctx.onInputKeyDown($event));
        });
        ɵɵelementEnd()();
        ɵɵelementStart(3, "span");
        ɵɵtemplate(4, CascadeSelect_ng_container_4_Template, 2, 5, "ng-container", 8)(5, CascadeSelect_ng_template_5_Template, 1, 1, "ng-template", null, 1, ɵɵtemplateRefExtractor);
        ɵɵelementEnd();
        ɵɵtemplate(7, CascadeSelect_ng_container_7_Template, 3, 2, "ng-container", 9);
        ɵɵelementStart(8, "div", 10);
        ɵɵtemplate(9, CascadeSelect_ng_container_9_Template, 3, 2, "ng-container", 8)(10, CascadeSelect_ng_template_10_Template, 2, 2, "ng-template", null, 2, ɵɵtemplateRefExtractor);
        ɵɵelementEnd();
        ɵɵelementStart(12, "span", 11);
        ɵɵtext(13);
        ɵɵelementEnd();
        ɵɵelementStart(14, "p-overlay", 12, 3);
        ɵɵtwoWayListener("visibleChange", function CascadeSelect_Template_p_overlay_visibleChange_14_listener($event) {
          ɵɵrestoreView(_r1);
          ɵɵtwoWayBindingSet(ctx.overlayVisible, $event) || (ctx.overlayVisible = $event);
          return ɵɵresetView($event);
        });
        ɵɵlistener("onAnimationDone", function CascadeSelect_Template_p_overlay_onAnimationDone_14_listener($event) {
          ɵɵrestoreView(_r1);
          return ɵɵresetView(ctx.onOverlayAnimationDone($event));
        })("onBeforeShow", function CascadeSelect_Template_p_overlay_onBeforeShow_14_listener($event) {
          ɵɵrestoreView(_r1);
          return ɵɵresetView(ctx.onBeforeShow.emit($event));
        })("onShow", function CascadeSelect_Template_p_overlay_onShow_14_listener($event) {
          ɵɵrestoreView(_r1);
          return ɵɵresetView(ctx.show($event));
        })("onBeforeHide", function CascadeSelect_Template_p_overlay_onBeforeHide_14_listener($event) {
          ɵɵrestoreView(_r1);
          return ɵɵresetView(ctx.onBeforeHide.emit($event));
        })("onHide", function CascadeSelect_Template_p_overlay_onHide_14_listener($event) {
          ɵɵrestoreView(_r1);
          return ɵɵresetView(ctx.hide($event));
        });
        ɵɵtemplate(16, CascadeSelect_ng_template_16_Template, 8, 25, "ng-template", null, 4, ɵɵtemplateRefExtractor);
        ɵɵelementEnd();
      }
      if (rf & 2) {
        const defaultValueTemplate_r6 = ɵɵreference(6);
        const elseBlock_r7 = ɵɵreference(11);
        ɵɵattribute("data-pc-section", "hiddenInputWrapper");
        ɵɵadvance();
        ɵɵproperty("pAutoFocus", ctx.autofocus);
        ɵɵattribute("name", ctx.name())("required", ctx.required() ? "" : void 0)("disabled", ctx.$disabled() ? "" : void 0)("placeholder", ctx.placeholder)("tabindex", !ctx.$disabled() ? ctx.tabindex : -1)("id", ctx.inputId)("aria-label", ctx.ariaLabel)("aria-labelledby", ctx.ariaLabelledBy)("aria-haspopup", "tree")("aria-expanded", ctx.overlayVisible ?? false)("aria-controls", ctx.overlayVisible ? ctx.id + "_tree" : null)("aria-activedescendant", ctx.focused ? ctx.focusedOptionId : void 0);
        ɵɵadvance(2);
        ɵɵclassMap(ctx.cx("label"));
        ɵɵattribute("data-pc-section", "label");
        ɵɵadvance();
        ɵɵproperty("ngIf", ctx.valueTemplate || ctx._valueTemplate)("ngIfElse", defaultValueTemplate_r6);
        ɵɵadvance(3);
        ɵɵproperty("ngIf", ctx.$filled() && !ctx.$disabled() && ctx.showClear);
        ɵɵadvance();
        ɵɵclassMap(ctx.cx("dropdown"));
        ɵɵattribute("aria-expanded", ctx.overlayVisible ?? false)("data-pc-section", "dropdownIcon")("aria-hidden", true);
        ɵɵadvance();
        ɵɵproperty("ngIf", ctx.loading)("ngIfElse", elseBlock_r7);
        ɵɵadvance(4);
        ɵɵtextInterpolate1(" ", ctx.searchResultMessageText, " ");
        ɵɵadvance();
        ɵɵproperty("hostAttrSelector", ctx.attrSelector);
        ɵɵtwoWayProperty("visible", ctx.overlayVisible);
        ɵɵproperty("options", ctx.overlayOptions)("target", "@parent")("appendTo", ctx.$appendTo());
      }
    },
    dependencies: [CommonModule, NgIf, NgTemplateOutlet, NgStyle, Overlay, AutoFocus, CascadeSelectSub, ChevronDownIcon, TimesIcon, SharedModule],
    encapsulation: 2,
    changeDetection: 0
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CascadeSelect, [{
    type: Component,
    args: [{
      selector: "p-cascadeSelect, p-cascadeselect, p-cascade-select",
      standalone: true,
      imports: [CommonModule, Overlay, AutoFocus, CascadeSelectSub, ChevronDownIcon, TimesIcon, SharedModule],
      template: `
        <div class="p-hidden-accessible" [attr.data-pc-section]="'hiddenInputWrapper'">
            <input
                #focusInput
                readonly
                type="text"
                role="combobox"
                [attr.name]="name()"
                [attr.required]="required() ? '' : undefined"
                [attr.disabled]="$disabled() ? '' : undefined"
                [attr.placeholder]="placeholder"
                [attr.tabindex]="!$disabled() ? tabindex : -1"
                [attr.id]="inputId"
                [attr.aria-label]="ariaLabel"
                [attr.aria-labelledby]="ariaLabelledBy"
                [attr.aria-haspopup]="'tree'"
                [attr.aria-expanded]="overlayVisible ?? false"
                [attr.aria-controls]="overlayVisible ? id + '_tree' : null"
                [attr.aria-activedescendant]="focused ? focusedOptionId : undefined"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (keydown)="onInputKeyDown($event)"
                [pAutoFocus]="autofocus"
            />
        </div>
        <span [class]="cx('label')" [attr.data-pc-section]="'label'">
            <ng-container *ngIf="valueTemplate || _valueTemplate; else defaultValueTemplate">
                <ng-container *ngTemplateOutlet="valueTemplate || _valueTemplate; context: { $implicit: value, placeholder: placeholder }"></ng-container>
            </ng-container>
            <ng-template #defaultValueTemplate>
                {{ label() }}
            </ng-template>
        </span>

        <ng-container *ngIf="$filled() && !$disabled() && showClear">
            <svg data-p-icon="times" *ngIf="!clearIconTemplate && !_clearIconTemplate" [class]="cx('clearIcon')" (click)="clear($event)" [attr.data-pc-section]="'clearicon'" [attr.aria-hidden]="true" />
            <span *ngIf="clearIconTemplate || _clearIconTemplate" [class]="cx('clearIcon')" (click)="clear($event)" [attr.data-pc-section]="'clearicon'" [attr.aria-hidden]="true">
                <ng-template *ngTemplateOutlet="clearIconTemplate || _clearIconTemplate"></ng-template>
            </span>
        </ng-container>

        <div [class]="cx('dropdown')" role="button" aria-haspopup="listbox" [attr.aria-expanded]="overlayVisible ?? false" [attr.data-pc-section]="'dropdownIcon'" [attr.aria-hidden]="true">
            <ng-container *ngIf="loading; else elseBlock">
                <ng-container *ngIf="loadingIconTemplate || _loadingIconTemplate">
                    <ng-container *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-container>
                </ng-container>
                <ng-container *ngIf="!loadingIconTemplate && !_loadingIconTemplate">
                    <span *ngIf="loadingIcon" [class]="cn(cx('loadingIcon'), loadingIcon + 'pi-spin')" aria-hidden="true"></span>
                    <span *ngIf="!loadingIcon" [class]="cn(cx('loadingIcon'), loadingIcon + ' pi pi-spinner pi-spin')" aria-hidden="true"></span>
                </ng-container>
            </ng-container>
            <ng-template #elseBlock>
                <svg data-p-icon="chevron-down" *ngIf="!triggerIconTemplate && !_triggerIconTemplate" [class]="cx('dropdownIcon')" />
                <span *ngIf="triggerIconTemplate || _triggerIconTemplate" [class]="cx('dropdownIcon')">
                    <ng-template *ngTemplateOutlet="triggerIconTemplate || _triggerIconTemplate"></ng-template>
                </span>
            </ng-template>
        </div>
        <span role="status" aria-live="polite" class="p-hidden-accessible">
            {{ searchResultMessageText }}
        </span>
        <p-overlay
            #overlay
            [hostAttrSelector]="attrSelector"
            [(visible)]="overlayVisible"
            [options]="overlayOptions"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            (onAnimationDone)="onOverlayAnimationDone($event)"
            (onBeforeShow)="onBeforeShow.emit($event)"
            (onShow)="show($event)"
            (onBeforeHide)="onBeforeHide.emit($event)"
            (onHide)="hide($event)"
        >
            <ng-template #content>
                <div #panel [class]="cn(cx('overlay'), panelStyleClass)" [ngStyle]="panelStyle" [attr.data-pc-section]="'panel'">
                    <ng-template *ngTemplateOutlet="headerTemplate || _headerTemplate"></ng-template>
                    <div [class]="cx('listContainer')" [attr.data-pc-section]="'wrapper'">
                        <p-cascadeselect-sub
                            [options]="processedOptions"
                            [selectId]="id"
                            [focusedOptionId]="focused ? focusedOptionId : undefined"
                            [activeOptionPath]="activeOptionPath()"
                            [optionLabel]="optionLabel"
                            [optionValue]="optionValue"
                            [level]="0"
                            [optionTemplate]="optionTemplate || _optionTemplate"
                            [groupicon]="groupIconTemplate || groupIconTemplate"
                            [optionGroupLabel]="optionGroupLabel"
                            [optionGroupChildren]="optionGroupChildren"
                            [optionDisabled]="optionDisabled"
                            [root]="true"
                            (onChange)="onOptionClick($event)"
                            (onFocusChange)="onOptionMouseMove($event)"
                            (onFocusEnterChange)="onOptionMouseEnter($event)"
                            [dirty]="dirty"
                            [role]="'tree'"
                        >
                        </p-cascadeselect-sub>
                    </div>
                    <span role="status" aria-live="polite" class="p-hidden-accessible">
                        {{ selectedMessageText }}
                    </span>
                    <ng-template *ngTemplateOutlet="footerTemplate || _footerTemplate"></ng-template>
                </div>
            </ng-template>
        </p-overlay>
    `,
      providers: [CASCADESELECT_VALUE_ACCESSOR, CascadeSelectStyle],
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation.None,
      host: {
        "[class]": "cn(cx('root'), styleClass)",
        "[style]": "sx('root')",
        "[attr.data-pc-name]": "'cascadeselect'",
        "[attr.data-pc-section]": "'root'"
      }
    }]
  }], () => [{
    type: OverlayService
  }], {
    id: [{
      type: Input
    }],
    searchMessage: [{
      type: Input
    }],
    emptyMessage: [{
      type: Input
    }],
    selectionMessage: [{
      type: Input
    }],
    emptySearchMessage: [{
      type: Input
    }],
    emptySelectionMessage: [{
      type: Input
    }],
    searchLocale: [{
      type: Input
    }],
    optionDisabled: [{
      type: Input
    }],
    focusOnHover: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    selectOnFocus: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    autoOptionFocus: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    styleClass: [{
      type: Input
    }],
    options: [{
      type: Input
    }],
    optionLabel: [{
      type: Input
    }],
    optionValue: [{
      type: Input
    }],
    optionGroupLabel: [{
      type: Input
    }],
    optionGroupChildren: [{
      type: Input
    }],
    placeholder: [{
      type: Input
    }],
    value: [{
      type: Input
    }],
    dataKey: [{
      type: Input
    }],
    inputId: [{
      type: Input
    }],
    tabindex: [{
      type: Input,
      args: [{
        transform: numberAttribute
      }]
    }],
    ariaLabelledBy: [{
      type: Input
    }],
    inputLabel: [{
      type: Input
    }],
    ariaLabel: [{
      type: Input
    }],
    showClear: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    panelStyleClass: [{
      type: Input
    }],
    panelStyle: [{
      type: Input
    }],
    overlayOptions: [{
      type: Input
    }],
    autofocus: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    loading: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    loadingIcon: [{
      type: Input
    }],
    breakpoint: [{
      type: Input
    }],
    onChange: [{
      type: Output
    }],
    onGroupChange: [{
      type: Output
    }],
    onShow: [{
      type: Output
    }],
    onHide: [{
      type: Output
    }],
    onClear: [{
      type: Output
    }],
    onBeforeShow: [{
      type: Output
    }],
    onBeforeHide: [{
      type: Output
    }],
    onFocus: [{
      type: Output
    }],
    onBlur: [{
      type: Output
    }],
    focusInputViewChild: [{
      type: ViewChild,
      args: ["focusInput"]
    }],
    panelViewChild: [{
      type: ViewChild,
      args: ["panel"]
    }],
    overlayViewChild: [{
      type: ViewChild,
      args: ["overlay"]
    }],
    valueTemplate: [{
      type: ContentChild,
      args: ["value", {
        descendants: false
      }]
    }],
    optionTemplate: [{
      type: ContentChild,
      args: ["option", {
        descendants: false
      }]
    }],
    headerTemplate: [{
      type: ContentChild,
      args: ["header", {
        descendants: false
      }]
    }],
    footerTemplate: [{
      type: ContentChild,
      args: ["footer", {
        descendants: false
      }]
    }],
    triggerIconTemplate: [{
      type: ContentChild,
      args: ["triggericon", {
        descendants: false
      }]
    }],
    loadingIconTemplate: [{
      type: ContentChild,
      args: ["loadingicon", {
        descendants: false
      }]
    }],
    groupIconTemplate: [{
      type: ContentChild,
      args: ["optiongroupicon", {
        descendants: false
      }]
    }],
    clearIconTemplate: [{
      type: ContentChild,
      args: ["clearicon", {
        descendants: false
      }]
    }],
    onHostClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var CascadeSelectModule = class _CascadeSelectModule {
  static ɵfac = function CascadeSelectModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _CascadeSelectModule)();
  };
  static ɵmod = ɵɵdefineNgModule({
    type: _CascadeSelectModule,
    imports: [CascadeSelect, SharedModule],
    exports: [CascadeSelect, SharedModule]
  });
  static ɵinj = ɵɵdefineInjector({
    imports: [CascadeSelect, SharedModule, SharedModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CascadeSelectModule, [{
    type: NgModule,
    args: [{
      imports: [CascadeSelect, SharedModule],
      exports: [CascadeSelect, SharedModule]
    }]
  }], null, null);
})();
export {
  CASCADESELECT_VALUE_ACCESSOR,
  CascadeSelect,
  CascadeSelectClasses,
  CascadeSelectModule,
  CascadeSelectStyle,
  CascadeSelectSub
};
//# sourceMappingURL=primeng_cascadeselect.js.map
