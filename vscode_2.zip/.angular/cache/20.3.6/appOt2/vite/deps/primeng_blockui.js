import {
  zindexutils
} from "./chunk-KGGKRTM5.js";
import {
  BaseComponent
} from "./chunk-HWI5RFTJ.js";
import {
  BaseStyle
} from "./chunk-HOGF5KIF.js";
import "./chunk-FVVHOTUL.js";
import {
  PrimeTemplate,
  SharedModule
} from "./chunk-ATRP6CAE.js";
import {
  dt,
  st
} from "./chunk-QUD74IZO.js";
import {
  CommonModule,
  NgTemplateOutlet,
  isPlatformBrowser
} from "./chunk-3VWL36ZD.js";
import "./chunk-ZMLREZMJ.js";
import {
  ChangeDetectionStrategy,
  Component,
  ContentChild,
  ContentChildren,
  Injectable,
  Input,
  NgModule,
  ViewEncapsulation,
  booleanAttribute,
  inject,
  numberAttribute,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵProvidersFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵelementContainer,
  ɵɵgetInheritedFactory,
  ɵɵloadQuery,
  ɵɵprojection,
  ɵɵprojectionDef,
  ɵɵproperty,
  ɵɵqueryRefresh,
  ɵɵtemplate
} from "./chunk-QLQLW64P.js";
import "./chunk-KWSTWQNB.js";

// node_modules/@primeuix/styles/dist/blockui/index.mjs
var style = "\n    .p-blockui {\n        position: relative;\n    }\n\n    .p-blockui-mask {\n        border-radius: dt('blockui.border.radius');\n    }\n\n    .p-blockui-mask.p-overlay-mask {\n        position: absolute;\n    }\n\n    .p-blockui-mask-document.p-overlay-mask {\n        position: fixed;\n    }\n";

// node_modules/primeng/fesm2022/primeng-blockui.mjs
var _c0 = ["content"];
var _c1 = ["*"];
function BlockUI_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var classes = {
  root: ({
    instance
  }) => ["p-blockui p-blockui-mask p-overlay-mask", {
    "p-blockui-mask-document": !instance.target
  }]
};
var BlockUiStyle = class _BlockUiStyle extends BaseStyle {
  name = "blockui";
  theme = style;
  classes = classes;
  static ɵfac = /* @__PURE__ */ (() => {
    let ɵBlockUiStyle_BaseFactory;
    return function BlockUiStyle_Factory(__ngFactoryType__) {
      return (ɵBlockUiStyle_BaseFactory || (ɵBlockUiStyle_BaseFactory = ɵɵgetInheritedFactory(_BlockUiStyle)))(__ngFactoryType__ || _BlockUiStyle);
    };
  })();
  static ɵprov = ɵɵdefineInjectable({
    token: _BlockUiStyle,
    factory: _BlockUiStyle.ɵfac
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BlockUiStyle, [{
    type: Injectable
  }], null, null);
})();
var BlockUIClasses;
(function(BlockUIClasses2) {
  BlockUIClasses2["root"] = "p-blockui";
})(BlockUIClasses || (BlockUIClasses = {}));
var BlockUI = class _BlockUI extends BaseComponent {
  /**
   * Name of the local ng-template variable referring to another component.
   * @group Props
   */
  target;
  /**
   * Whether to automatically manage layering.
   * @group Props
   */
  autoZIndex = true;
  /**
   * Base zIndex value to use in layering.
   * @group Props
   */
  baseZIndex = 0;
  /**
   * Class of the element.
   * @deprecated since v20.0.0, use `class` instead.
   * @group Props
   */
  styleClass;
  /**
   * Current blocked state as a boolean.
   * @group Props
   */
  get blocked() {
    return this._blocked;
  }
  set blocked(val) {
    if (this.el && this.el.nativeElement) {
      if (val) this.block();
      else this.unblock();
    } else {
      this._blocked = val;
    }
  }
  /**
   * template of the content
   * @group Templates
   */
  contentTemplate;
  _blocked = false;
  animationEndListener;
  _componentStyle = inject(BlockUiStyle);
  constructor() {
    super();
  }
  ngAfterViewInit() {
    super.ngAfterViewInit();
    if (this._blocked) this.block();
    if (this.target && !this.target.getBlockableElement) {
      throw "Target of BlockUI must implement BlockableUI interface";
    }
  }
  _contentTemplate;
  templates;
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "content":
          this.contentTemplate = item.template;
          break;
        default:
          this.contentTemplate = item.template;
          break;
      }
    });
  }
  block() {
    if (isPlatformBrowser(this.platformId)) {
      this._blocked = true;
      this.el.nativeElement.style.display = "flex";
      if (this.target) {
        this.target.getBlockableElement().appendChild(this.el.nativeElement);
        this.target.getBlockableElement().style.position = "relative";
      } else {
        this.renderer.appendChild(this.document.body, this.el.nativeElement);
        st();
      }
      if (this.autoZIndex) {
        zindexutils.set("modal", this.el.nativeElement, this.baseZIndex + this.config.zIndex.modal);
      }
    }
  }
  unblock() {
    if (isPlatformBrowser(this.platformId) && this.el && !this.animationEndListener) {
      this.destroyModal();
    }
  }
  destroyModal() {
    this._blocked = false;
    if (this.el && isPlatformBrowser(this.platformId)) {
      zindexutils.clear(this.el.nativeElement);
      this.renderer.removeChild(this.el.nativeElement, this.el.nativeElement);
      dt();
    }
    this.unbindAnimationEndListener();
    this.cd.markForCheck();
  }
  unbindAnimationEndListener() {
    if (this.animationEndListener && this.el) {
      this.animationEndListener();
      this.animationEndListener = null;
    }
  }
  ngOnDestroy() {
    this.unblock();
    this.destroyModal();
    super.ngOnDestroy();
  }
  static ɵfac = function BlockUI_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BlockUI)();
  };
  static ɵcmp = ɵɵdefineComponent({
    type: _BlockUI,
    selectors: [["p-blockUI"], ["p-blockui"], ["p-block-ui"]],
    contentQueries: function BlockUI_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuery(dirIndex, _c0, 4);
        ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
      }
      if (rf & 2) {
        let _t;
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.contentTemplate = _t.first);
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
      }
    },
    hostVars: 5,
    hostBindings: function BlockUI_HostBindings(rf, ctx) {
      if (rf & 2) {
        ɵɵattribute("aria-busy", ctx.blocked)("data-pc-name", "blockui")("data-pc-section", "root");
        ɵɵclassMap(ctx.cn(ctx.cx("root"), ctx.styleClass));
      }
    },
    inputs: {
      target: "target",
      autoZIndex: [2, "autoZIndex", "autoZIndex", booleanAttribute],
      baseZIndex: [2, "baseZIndex", "baseZIndex", numberAttribute],
      styleClass: "styleClass",
      blocked: [2, "blocked", "blocked", booleanAttribute]
    },
    features: [ɵɵProvidersFeature([BlockUiStyle]), ɵɵInheritDefinitionFeature],
    ngContentSelectors: _c1,
    decls: 2,
    vars: 1,
    consts: [[4, "ngTemplateOutlet"]],
    template: function BlockUI_Template(rf, ctx) {
      if (rf & 1) {
        ɵɵprojectionDef();
        ɵɵprojection(0);
        ɵɵtemplate(1, BlockUI_ng_container_1_Template, 1, 0, "ng-container", 0);
      }
      if (rf & 2) {
        ɵɵadvance();
        ɵɵproperty("ngTemplateOutlet", ctx.contentTemplate || ctx._contentTemplate);
      }
    },
    dependencies: [CommonModule, NgTemplateOutlet, SharedModule],
    encapsulation: 2,
    changeDetection: 0
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BlockUI, [{
    type: Component,
    args: [{
      selector: "p-blockUI, p-blockui, p-block-ui",
      standalone: true,
      imports: [CommonModule, SharedModule],
      template: `
        <ng-content></ng-content>
        <ng-container *ngTemplateOutlet="contentTemplate || _contentTemplate"></ng-container>
    `,
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation.None,
      providers: [BlockUiStyle],
      host: {
        "[attr.aria-busy]": "blocked",
        "[attr.data-pc-name]": "'blockui'",
        "[attr.data-pc-section]": "'root'",
        "[class]": "cn(cx('root'), styleClass)"
      }
    }]
  }], () => [], {
    target: [{
      type: Input
    }],
    autoZIndex: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    baseZIndex: [{
      type: Input,
      args: [{
        transform: numberAttribute
      }]
    }],
    styleClass: [{
      type: Input
    }],
    blocked: [{
      type: Input,
      args: [{
        transform: booleanAttribute
      }]
    }],
    contentTemplate: [{
      type: ContentChild,
      args: ["content", {
        descendants: false
      }]
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var BlockUIModule = class _BlockUIModule {
  static ɵfac = function BlockUIModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _BlockUIModule)();
  };
  static ɵmod = ɵɵdefineNgModule({
    type: _BlockUIModule,
    imports: [BlockUI, SharedModule],
    exports: [BlockUI, SharedModule]
  });
  static ɵinj = ɵɵdefineInjector({
    imports: [BlockUI, SharedModule, SharedModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(BlockUIModule, [{
    type: NgModule,
    args: [{
      imports: [BlockUI, SharedModule],
      exports: [BlockUI, SharedModule]
    }]
  }], null, null);
})();
export {
  BlockUI,
  BlockUIClasses,
  BlockUIModule,
  BlockUiStyle
};
//# sourceMappingURL=primeng_blockui.js.map
