import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-HOGF5KIF.js";
import "./chunk-FVVHOTUL.js";
import "./chunk-ATRP6CAE.js";
import "./chunk-QUD74IZO.js";
import "./chunk-3VWL36ZD.js";
import "./chunk-ZMLREZMJ.js";
import "./chunk-QLQLW64P.js";
import "./chunk-KWSTWQNB.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
