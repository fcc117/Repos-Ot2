import {
  DefaultValueAccessor,
  FormsModule,
  NgControlStatus,
  NgModel
} from "./chunk-OWDQLOGR.js";
import {
  BaseComponent
} from "./chunk-HWI5RFTJ.js";
import {
  BaseStyle
} from "./chunk-HOGF5KIF.js";
import "./chunk-FVVHOTUL.js";
import {
  SharedModule
} from "./chunk-ATRP6CAE.js";
import {
  Y
} from "./chunk-QUD74IZO.js";
import {
  CommonModule,
  NgForOf,
  NgIf
} from "./chunk-3VWL36ZD.js";
import "./chunk-ZMLREZMJ.js";
import {
  ChangeDetectionStrategy,
  Component,
  HostListener,
  Injectable,
  Input,
  NgModule,
  Subject,
  ViewChild,
  ViewEncapsulation,
  inject,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵProvidersFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵdefineComponent,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵqueryRefresh,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtwoWayBindingSet,
  ɵɵtwoWayListener,
  ɵɵtwoWayProperty,
  ɵɵviewQuery
} from "./chunk-QLQLW64P.js";
import "./chunk-KWSTWQNB.js";

// node_modules/@primeuix/styles/dist/terminal/index.mjs
var style = "\n    .p-terminal {\n        display: block;\n        height: dt('terminal.height');\n        overflow: auto;\n        background: dt('terminal.background');\n        color: dt('terminal.color');\n        border: 1px solid dt('terminal.border.color');\n        padding: dt('terminal.padding');\n        border-radius: dt('terminal.border.radius');\n    }\n\n    .p-terminal-prompt {\n        display: flex;\n        align-items: center;\n    }\n\n    .p-terminal-prompt-value {\n        flex: 1 1 auto;\n        border: 0 none;\n        background: transparent;\n        color: inherit;\n        padding: 0;\n        outline: 0 none;\n        font-family: inherit;\n        font-feature-settings: inherit;\n        font-size: 1rem;\n    }\n\n    .p-terminal-prompt-label {\n        margin-inline-end: dt('terminal.prompt.gap');\n    }\n\n    .p-terminal-input::-ms-clear {\n        display: none;\n    }\n\n    .p-terminal-command-response {\n        margin: dt('terminal.command.response.margin');\n    }\n";

// node_modules/primeng/fesm2022/primeng-terminal.mjs
var _c0 = ["in"];
function Terminal_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵclassMap(ctx_r1.cx("welcomeMessage"));
    ɵɵadvance();
    ɵɵtextInterpolate(ctx_r1.welcomeMessage);
  }
}
function Terminal_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div")(1, "span");
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵelementStart(3, "span");
    ɵɵtext(4);
    ɵɵelementEnd();
    ɵɵelementStart(5, "div");
    ɵɵtext(6);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const command_r3 = ctx.$implicit;
    const ctx_r1 = ɵɵnextContext();
    ɵɵclassMap(ctx_r1.cx("command"));
    ɵɵadvance();
    ɵɵclassMap(ctx_r1.cx("promptLabel"));
    ɵɵadvance();
    ɵɵtextInterpolate(ctx_r1.prompt);
    ɵɵadvance();
    ɵɵclassMap(ctx_r1.cx("commandValue"));
    ɵɵadvance();
    ɵɵtextInterpolate(command_r3.text);
    ɵɵadvance();
    ɵɵclassMap(ctx_r1.cx("commandResponse"));
    ɵɵattribute("aria-live", "polite");
    ɵɵadvance();
    ɵɵtextInterpolate(command_r3.response);
  }
}
var classes = {
  root: () => ["p-terminal p-component"],
  welcomeMessage: "p-terminal-welcome-message",
  commandList: "p-terminal-command-list",
  command: "p-terminal-command",
  commandValue: "p-terminal-command-value",
  commandResponse: "p-terminal-command-response",
  prompt: "p-terminal-prompt",
  promptLabel: "p-terminal-prompt-label",
  promptValue: "p-terminal-prompt-value"
};
var TerminalStyle = class _TerminalStyle extends BaseStyle {
  name = "terminal";
  theme = style;
  classes = classes;
  static ɵfac = /* @__PURE__ */ (() => {
    let ɵTerminalStyle_BaseFactory;
    return function TerminalStyle_Factory(__ngFactoryType__) {
      return (ɵTerminalStyle_BaseFactory || (ɵTerminalStyle_BaseFactory = ɵɵgetInheritedFactory(_TerminalStyle)))(__ngFactoryType__ || _TerminalStyle);
    };
  })();
  static ɵprov = ɵɵdefineInjectable({
    token: _TerminalStyle,
    factory: _TerminalStyle.ɵfac
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TerminalStyle, [{
    type: Injectable
  }], null, null);
})();
var TerminalClasses;
(function(TerminalClasses2) {
  TerminalClasses2["root"] = "p-terminal";
  TerminalClasses2["welcomeMessage"] = "p-terminal-welcome-message";
  TerminalClasses2["commandList"] = "p-terminal-command-list";
  TerminalClasses2["command"] = "p-terminal-command";
  TerminalClasses2["commandValue"] = "p-terminal-command-value";
  TerminalClasses2["commandResponse"] = "p-terminal-command-response";
  TerminalClasses2["prompt"] = "p-terminal-prompt";
  TerminalClasses2["promptLabel"] = "p-terminal-prompt-label";
  TerminalClasses2["promptValue"] = "p-terminal-prompt-value";
})(TerminalClasses || (TerminalClasses = {}));
var TerminalService = class _TerminalService {
  commandSource = new Subject();
  responseSource = new Subject();
  commandHandler = this.commandSource.asObservable();
  responseHandler = this.responseSource.asObservable();
  sendCommand(command) {
    if (command) {
      this.commandSource.next(command);
    }
  }
  sendResponse(response) {
    if (response) {
      this.responseSource.next(response);
    }
  }
  static ɵfac = function TerminalService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _TerminalService)();
  };
  static ɵprov = ɵɵdefineInjectable({
    token: _TerminalService,
    factory: _TerminalService.ɵfac
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TerminalService, [{
    type: Injectable
  }], null, null);
})();
var Terminal = class _Terminal extends BaseComponent {
  terminalService;
  /**
   * Initial text to display on terminal.
   * @group Props
   */
  welcomeMessage;
  /**
   * Prompt text for each command.
   * @group Props
   */
  prompt;
  /**
   * Style class of the component.
   * @deprecated since v20.0.0, use `class` instead.
   * @group Props
   */
  styleClass;
  commands = [];
  command;
  container;
  commandProcessed;
  subscription;
  _componentStyle = inject(TerminalStyle);
  inputRef;
  onHostClick() {
    this.focus(this.inputRef?.nativeElement);
  }
  constructor(terminalService) {
    super();
    this.terminalService = terminalService;
    this.subscription = terminalService.responseHandler.subscribe((response) => {
      this.commands[this.commands.length - 1].response = response;
      this.commandProcessed = true;
    });
  }
  ngAfterViewInit() {
    super.ngAfterViewInit();
    this.container = Y(this.el.nativeElement, ".p-terminal")[0];
  }
  ngAfterViewChecked() {
    if (this.commandProcessed) {
      this.container.scrollTop = this.container.scrollHeight;
      this.commandProcessed = false;
    }
  }
  set response(value) {
    if (value) {
      this.commands[this.commands.length - 1].response = value;
      this.commandProcessed = true;
    }
  }
  handleCommand(event) {
    if (event.keyCode == 13) {
      this.commands.push({
        text: this.command
      });
      this.terminalService.sendCommand(this.command);
      this.command = "";
    }
  }
  focus(element) {
    element.focus();
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
    super.ngOnDestroy();
  }
  static ɵfac = function Terminal_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _Terminal)(ɵɵdirectiveInject(TerminalService));
  };
  static ɵcmp = ɵɵdefineComponent({
    type: _Terminal,
    selectors: [["p-terminal"]],
    viewQuery: function Terminal_Query(rf, ctx) {
      if (rf & 1) {
        ɵɵviewQuery(_c0, 5);
      }
      if (rf & 2) {
        let _t;
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.inputRef = _t.first);
      }
    },
    hostVars: 2,
    hostBindings: function Terminal_HostBindings(rf, ctx) {
      if (rf & 1) {
        ɵɵlistener("click", function Terminal_click_HostBindingHandler() {
          return ctx.onHostClick();
        });
      }
      if (rf & 2) {
        ɵɵclassMap(ctx.cn(ctx.cx("root"), ctx.styleClass));
      }
    },
    inputs: {
      welcomeMessage: "welcomeMessage",
      prompt: "prompt",
      styleClass: "styleClass",
      response: "response"
    },
    features: [ɵɵProvidersFeature([TerminalStyle]), ɵɵInheritDefinitionFeature],
    decls: 8,
    vars: 12,
    consts: [["in", ""], [3, "class", 4, "ngIf"], [3, "class", 4, "ngFor", "ngForOf"], ["type", "text", "autocomplete", "off", "autofocus", "", 3, "ngModelChange", "keydown", "ngModel"]],
    template: function Terminal_Template(rf, ctx) {
      if (rf & 1) {
        const _r1 = ɵɵgetCurrentView();
        ɵɵtemplate(0, Terminal_div_0_Template, 2, 3, "div", 1);
        ɵɵelementStart(1, "div");
        ɵɵtemplate(2, Terminal_div_2_Template, 7, 12, "div", 2);
        ɵɵelementEnd();
        ɵɵelementStart(3, "div")(4, "span");
        ɵɵtext(5);
        ɵɵelementEnd();
        ɵɵelementStart(6, "input", 3, 0);
        ɵɵtwoWayListener("ngModelChange", function Terminal_Template_input_ngModelChange_6_listener($event) {
          ɵɵrestoreView(_r1);
          ɵɵtwoWayBindingSet(ctx.command, $event) || (ctx.command = $event);
          return ɵɵresetView($event);
        });
        ɵɵlistener("keydown", function Terminal_Template_input_keydown_6_listener($event) {
          ɵɵrestoreView(_r1);
          return ɵɵresetView(ctx.handleCommand($event));
        });
        ɵɵelementEnd()();
      }
      if (rf & 2) {
        ɵɵproperty("ngIf", ctx.welcomeMessage);
        ɵɵadvance();
        ɵɵclassMap(ctx.cx("commandList"));
        ɵɵadvance();
        ɵɵproperty("ngForOf", ctx.commands);
        ɵɵadvance();
        ɵɵclassMap(ctx.cx("prompt"));
        ɵɵadvance();
        ɵɵclassMap(ctx.cx("promptLabel"));
        ɵɵadvance();
        ɵɵtextInterpolate(ctx.prompt);
        ɵɵadvance();
        ɵɵclassMap(ctx.cx("promptValue"));
        ɵɵtwoWayProperty("ngModel", ctx.command);
      }
    },
    dependencies: [CommonModule, NgForOf, NgIf, FormsModule, DefaultValueAccessor, NgControlStatus, NgModel, SharedModule],
    encapsulation: 2,
    changeDetection: 0
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Terminal, [{
    type: Component,
    args: [{
      selector: "p-terminal",
      standalone: true,
      imports: [CommonModule, FormsModule, SharedModule],
      template: `
        <div [class]="cx('welcomeMessage')" *ngIf="welcomeMessage">{{ welcomeMessage }}</div>
        <div [class]="cx('commandList')">
            <div [class]="cx('command')" *ngFor="let command of commands">
                <span [class]="cx('promptLabel')">{{ prompt }}</span>
                <span [class]="cx('commandValue')">{{ command.text }}</span>
                <div [class]="cx('commandResponse')" [attr.aria-live]="'polite'">{{ command.response }}</div>
            </div>
        </div>
        <div [class]="cx('prompt')">
            <span [class]="cx('promptLabel')">{{ prompt }}</span>
            <input #in type="text" [(ngModel)]="command" [class]="cx('promptValue')" autocomplete="off" (keydown)="handleCommand($event)" autofocus />
        </div>
    `,
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation.None,
      providers: [TerminalStyle],
      host: {
        "[class]": "cn(cx('root'), styleClass)"
      }
    }]
  }], () => [{
    type: TerminalService
  }], {
    welcomeMessage: [{
      type: Input
    }],
    prompt: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    inputRef: [{
      type: ViewChild,
      args: ["in"]
    }],
    onHostClick: [{
      type: HostListener,
      args: ["click"]
    }],
    response: [{
      type: Input
    }]
  });
})();
var TerminalModule = class _TerminalModule {
  static ɵfac = function TerminalModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _TerminalModule)();
  };
  static ɵmod = ɵɵdefineNgModule({
    type: _TerminalModule,
    imports: [Terminal, SharedModule],
    exports: [Terminal, SharedModule]
  });
  static ɵinj = ɵɵdefineInjector({
    imports: [Terminal, SharedModule, SharedModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TerminalModule, [{
    type: NgModule,
    args: [{
      exports: [Terminal, SharedModule],
      imports: [Terminal, SharedModule]
    }]
  }], null, null);
})();
export {
  Terminal,
  TerminalClasses,
  TerminalModule,
  TerminalService,
  TerminalStyle
};
//# sourceMappingURL=primeng_terminal.js.map
